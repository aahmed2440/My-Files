
from __future__ import annotations
from typing import Dict, Any

from adaptive_contingency_policy import resilience_need_index

def _clamp(v,lo=0.0,hi=100.0):
    return max(lo,min(hi,float(v)))

def mission_need_decomposition(mission_context: Dict[str,Any]) -> Dict[str,Any]:
    r=resilience_need_index(mission_context)
    c=r["normalized_context"]
    contributions={
        "mission_criticality":round(0.28*c["mission_criticality"],2),
        "consequence_severity":round(0.26*c["consequence_severity"],2),
        "uncertainty":round(0.16*c["uncertainty"],2),
        "external_dependency_exposure":round(
            0.12*c["external_dependency_exposure"],2
        ),
        "low_reversibility":round(0.10*(100-c["reversibility"]),2),
        "evidence_quality_gap":round(0.08*(100-c["evidence_quality"]),2),
    }
    return {
        "resilience_need_index":r["resilience_need_index"],
        "need_band":r["need_band"],
        "normalized_context":c,
        "contributions":contributions,
        "probability":False,
    }

def renewal_option_comparison(v089_assessment: Dict[str,Any]) -> Dict[str,Any]:
    eff=v089_assessment["v088_efficiency_portfolio"]
    rob=v089_assessment["regret_stable_portfolio"]

    rank={
        r["portfolio_id"]:r
        for r in v089_assessment["rank_stability"]["portfolio_rank_summary"]
    }
    regret={
        r["portfolio_id"]:r
        for r in v089_assessment["regret_analysis"]["portfolio_regret"]
    }

    eff_rank=rank[eff["portfolio_id"]]
    rob_rank=rank[rob["portfolio_id"]]
    eff_regret=regret[eff["portfolio_id"]]
    rob_regret=regret[rob["portfolio_id"]]

    premium=round(
        float(rob["review_burden_proxy"])
        - float(eff["review_burden_proxy"]),2
    )
    premium_pct=round(
        100*premium/max(0.5,float(eff["review_burden_proxy"])),2
    )
    coverage_gain=round(
        float(rob["tested_scenario_coverage_pct"])
        - float(eff["tested_scenario_coverage_pct"]),2
    )
    worst_support_gain=round(
        float(rob["worst_minimum_support_score"])
        - float(eff["worst_minimum_support_score"]),2
    )
    max_regret_reduction=round(
        float(eff_regret["maximum_regret_support_points"])
        - float(rob_regret["maximum_regret_support_points"]),2
    )
    worst_rank_improvement=round(
        float(eff_rank["worst_rank"])
        - float(rob_rank["worst_rank"]),2
    )

    # Heuristic gain index for governance comparison only.
    gain_index=round(100*(
        0.35*min(1.0,max(0.0,coverage_gain)/25.0)
        + 0.30*min(1.0,max(0.0,worst_support_gain)/2.0)
        + 0.25*min(1.0,max(0.0,max_regret_reduction)/2.0)
        + 0.10*min(1.0,max(0.0,worst_rank_improvement)/2.0)
    ),2)

    return {
        "efficiency_portfolio":{
            "portfolio_id":eff["portfolio_id"],
            "review_burden_proxy":eff["review_burden_proxy"],
            "tested_scenario_coverage_pct":
                eff["tested_scenario_coverage_pct"],
            "worst_minimum_support_score":
                eff["worst_minimum_support_score"],
            "worst_rank":eff_rank["worst_rank"],
            "maximum_regret_support_points":
                eff_regret["maximum_regret_support_points"],
        },
        "robust_portfolio":{
            "portfolio_id":rob["portfolio_id"],
            "review_burden_proxy":rob["review_burden_proxy"],
            "tested_scenario_coverage_pct":
                rob["tested_scenario_coverage_pct"],
            "worst_minimum_support_score":
                rob["worst_minimum_support_score"],
            "worst_rank":rob_rank["worst_rank"],
            "maximum_regret_support_points":
                rob_regret["maximum_regret_support_points"],
        },
        "incremental_review_burden_proxy":premium,
        "premium_pct_vs_efficiency_burden":premium_pct,
        "tested_coverage_gain_pct_points":coverage_gain,
        "worst_support_gain_points":worst_support_gain,
        "maximum_regret_reduction_points":max_regret_reduction,
        "worst_rank_improvement":worst_rank_improvement,
        "robustness_gain_index":gain_index,
        "robustness_gain_index_is_probability":False,
        "financial_premium":False,
    }

def proportional_selection_boundary(option_comparison: Dict[str,Any]) -> Dict[str,Any]:
    premium_pct=float(
        option_comparison["premium_pct_vs_efficiency_burden"]
    )
    gain=float(option_comparison["robustness_gain_index"])

    # Transparent heuristic policy boundary. Higher burden raises the threshold;
    # stronger robustness gain lowers it. Not empirically calibrated.
    threshold=round(_clamp(
        60.0 + 0.30*premium_pct - 0.20*gain,
        45.0,90.0
    ),2)

    return {
        "robustness_selection_need_threshold":threshold,
        "formula":
            "clamp(60 + 0.30*premium_pct_vs_efficiency "
            "- 0.20*robustness_gain_index, 45, 90)",
        "empirically_calibrated":False,
        "probability_threshold":False,
        "automatic_policy_activation":False,
    }

def mission_proportional_renewal_policy(
    v089_assessment: Dict[str,Any],
    mission_context: Dict[str,Any]
) -> Dict[str,Any]:
    need=mission_need_decomposition(mission_context)
    options=renewal_option_comparison(v089_assessment)
    boundary=proportional_selection_boundary(options)

    score=float(need["resilience_need_index"])
    threshold=float(boundary["robustness_selection_need_threshold"])
    margin=round(score-threshold,2)

    if score>=threshold:
        selected=options["robust_portfolio"]
        posture="ROBUSTNESS_PREMIUM_JUSTIFIED_FOR_HUMAN_REVIEW"
        rationale=(
            "Mission resilience need meets the declared heuristic boundary "
            "for paying the additional review-burden premium."
        )
    else:
        selected=options["efficiency_portfolio"]
        posture="EFFICIENCY_PORTFOLIO_PROPORTIONATE_FOR_HUMAN_REVIEW"
        rationale=(
            "Mission resilience need remains below the declared heuristic "
            "boundary for the robustness premium."
        )

    if abs(margin)<=5:
        stability="NEAR_POLICY_BOUNDARY"
    elif margin>5:
        stability="CLEARLY_ABOVE_POLICY_BOUNDARY"
    else:
        stability="CLEARLY_BELOW_POLICY_BOUNDARY"

    return {
        "mission_need":need,
        "option_comparison":options,
        "selection_boundary":boundary,
        "selected_portfolio_candidate":selected,
        "policy_margin_points":margin,
        "policy_boundary_stability":stability,
        "posture":posture,
        "rationale":rationale,
        "selection_is_probability":False,
        "financial_roi":False,
        "financial_premium":False,
        "automatic_evidence_collection":False,
        "automatic_contact":False,
        "automatic_evidence_acceptance":False,
        "automatic_revalidation":False,
        "automatic_scheduling":False,
        "automatic_policy_activation":False,
        "automatic_policy_mutation":False,
        "production_execution":False,
        "human_governance_required":True,
        "semantics":
            "mission-proportionate advisory selection between verified "
            "efficiency and regret-stable renewal portfolios",
    }
