from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field

from evidence_sequence_policy import evidence_sequence_policy
from post_evidence_revalidation import post_evidence_revalidation_assurance
from mission_proportional_renewal import mission_proportional_renewal_policy

ROOT = Path(__file__).resolve().parent
RELEASE = ROOT / "release"
APP_VERSION = "0.90.1"

app = FastAPI(
    title="CryptoSphere Analytical Engine",
    version=APP_VERSION,
    docs_url=None,
    redoc_url=None,
    openapi_url="/api/v1/openapi.json",
)

SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
    "X-Frame-Options": "DENY",
    "Cross-Origin-Opener-Policy": "same-origin",
    "Cross-Origin-Resource-Policy": "same-origin",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=(), payment=(), usb=()",
    "Content-Security-Policy": (
        "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
        "connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; "
        "form-action 'self'"
    ),
    "Cache-Control": "no-store",
}


@app.middleware("http")
async def harden_headers(request: Request, call_next):
    response = await call_next(request)
    for key, value in SECURITY_HEADERS.items():
        response.headers.setdefault(key, value)
    if request.url.scheme == "https":
        response.headers.setdefault("Strict-Transport-Security", "max-age=31536000")
    return response


def _load_json(name: str) -> Dict[str, Any]:
    p = RELEASE / name
    if not p.exists():
        raise RuntimeError(f"release evidence missing: {name}")
    return json.loads(p.read_text(encoding="utf-8"))


def _release_assessment(name: str, key: str = "assessment") -> Dict[str, Any]:
    data = _load_json(name)
    if key not in data:
        raise RuntimeError(f"release evidence {name} missing key {key}")
    return data[key]


V087 = _release_assessment("adaptive-evidence-renewal.json")
V088 = _release_assessment("minimum-durable-renewal.json", "plan")
V089 = _release_assessment("renewal-robustness-compound-stress.json")
INFLUENCE = _release_assessment("decision-confidence-evidence-requirements.json")["assumption_influence"]


class MissionContext(BaseModel):
    mission_criticality: float = Field(ge=0, le=100)
    consequence_severity: float = Field(ge=0, le=100)
    reversibility: float = Field(ge=0, le=100)
    evidence_quality: float = Field(ge=0, le=100)
    uncertainty: float = Field(ge=0, le=100)
    external_dependency_exposure: float = Field(ge=0, le=100)


class EvidenceSequenceRequest(BaseModel):
    cases: List[Dict[str, Any]]
    base_review_units_by_case: Dict[str, float]
    available_review_units: float = Field(ge=0)
    mission_context: MissionContext
    assumption_evidence: List[Dict[str, Any]] = []
    evaluation_time: datetime
    max_steps: int = Field(default=5, ge=1, le=8)
    min_marginal_uplift: float = Field(default=0.5, ge=0, le=100)
    max_total_review_burden_proxy: float = Field(default=6.0, ge=0, le=25)
    max_scenarios: int = Field(default=24, ge=4, le=48)


class RevalidationRequest(BaseModel):
    cases: List[Dict[str, Any]]
    base_review_units_by_case: Dict[str, float]
    available_review_units: float = Field(ge=0)
    mission_context: MissionContext
    assumption_evidence: List[Dict[str, Any]] = []
    evaluation_time: datetime
    max_scenarios: int = Field(default=24, ge=4, le=48)


def _mode() -> str:
    return str(os.getenv("CRYPTOSPHERE_CORE_MODE", "ADVISORY_ONLY")).upper()


def _authority_boundary() -> Dict[str, Any]:
    return {
        "production_execution": False,
        "automatic_policy_activation": False,
        "automatic_policy_mutation": False,
        "automatic_evidence_collection": False,
        "automatic_scheduling": False,
        "human_governance_required": True,
    }


@app.get("/health/live")
def live():
    return {"status": "live", "version": APP_VERSION}


@app.get("/health/ready")
def ready():
    required = [
        "adaptive-evidence-renewal.json",
        "minimum-durable-renewal.json",
        "renewal-robustness-compound-stress.json",
        "decision-confidence-evidence-requirements.json",
    ]
    missing = [name for name in required if not (RELEASE / name).exists()]
    return {
        "status": "ready" if not missing else "not_ready",
        "version": APP_VERSION,
        "mode": _mode(),
        "release_evidence_missing": missing,
        **_authority_boundary(),
    }


@app.get("/api/v1/status")
def api_status():
    return {
        "service": "CryptoSphere Analytical Engine",
        "version": APP_VERSION,
        "core_model_version": "0.90",
        "integration_release": "0.90.1",
        "mode": _mode(),
        "regression_baseline": {"versioned_tests": 52, "passed": 52},
        "performance_closure": {
            "v085_evidence_sequence_seconds": 0.90,
            "v086_post_revalidation_seconds": 1.72,
            "measurement_context": "local closure host; indicative, not an SLA",
        },
        **_authority_boundary(),
    }


@app.get("/api/v1/ui/bootstrap")
def ui_bootstrap():
    robust = V089["regret_stable_portfolio"]
    eff = V089["v088_efficiency_portfolio"]
    rank = {r["portfolio_id"]: r for r in V089["rank_stability"]["portfolio_rank_summary"]}
    default_ctx = MissionContext(
        mission_criticality=95,
        consequence_severity=90,
        reversibility=25,
        evidence_quality=70,
        uncertainty=65,
        external_dependency_exposure=75,
    )
    mpr = mission_proportional_renewal_policy(V089, default_ctx.model_dump())
    selected = V088.get("minimum_durable_portfolio") or {}
    return {
        "version": APP_VERSION,
        "v088": {
            "target_days": V088["target_sampled_degradation_boundary_days"],
            "selected_burden": selected.get("review_burden_proxy"),
            "first_degradation": selected.get("first_sampled_degradation_relative_day"),
            "selected_portfolio": selected.get("portfolio_id"),
            "pareto_count": len(V088.get("pareto_frontier", [])),
        },
        "v089": {
            "scenario_count": len(V089["stress_scenarios"]),
            "selected_portfolio": robust["portfolio_id"],
            "worst_rank": rank[robust["portfolio_id"]]["worst_rank"],
            "efficiency_portfolio": eff["portfolio_id"],
            "posture": V089["posture"],
        },
        "v090": mpr,
        **_authority_boundary(),
    }


@app.post("/api/v1/renewal/mission-proportional")
def mission_proportional(context: MissionContext):
    result = mission_proportional_renewal_policy(V089, context.model_dump())
    return {"version": APP_VERSION, "analysis": result, **_authority_boundary()}


@app.post("/api/v1/evidence/sequence")
def evidence_sequence(payload: EvidenceSequenceRequest):
    try:
        result = evidence_sequence_policy(
            payload.cases,
            payload.base_review_units_by_case,
            payload.available_review_units,
            payload.mission_context.model_dump(),
            payload.assumption_evidence,
            payload.evaluation_time,
            max_steps=payload.max_steps,
            min_marginal_uplift=payload.min_marginal_uplift,
            max_total_review_burden_proxy=payload.max_total_review_burden_proxy,
            max_scenarios=payload.max_scenarios,
        )
        return {"version": APP_VERSION, "analysis": result, **_authority_boundary()}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)[:240]) from exc


@app.post("/api/v1/evidence/revalidation")
def evidence_revalidation(payload: RevalidationRequest):
    try:
        result = post_evidence_revalidation_assurance(
            payload.cases,
            payload.base_review_units_by_case,
            payload.available_review_units,
            payload.mission_context.model_dump(),
            payload.assumption_evidence,
            payload.evaluation_time,
            max_scenarios=payload.max_scenarios,
        )
        return {"version": APP_VERSION, "analysis": result, **_authority_boundary()}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)[:240]) from exc


@app.get("/")
def root():
    return FileResponse(ROOT / "index.html", media_type="text/html")


@app.get("/app.js")
def app_js():
    return FileResponse(ROOT / "app.js", media_type="application/javascript")


@app.get("/styles.css")
def styles_css():
    return FileResponse(ROOT / "styles.css", media_type="text/css")


@app.exception_handler(404)
async def not_found(_: Request, __):
    return JSONResponse(status_code=404, content={"status": "NOT_FOUND"})
