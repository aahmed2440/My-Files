
from __future__ import annotations
from typing import Dict, Any, List
from shared_evidence_reuse import shared_evidence_capacity_plan

def augmentation_candidates(residual_gap_units: float, step: float=1.0,
                            max_extra_units: float|None=None) -> List[float]:
    gap=max(0.0,float(residual_gap_units))
    if max_extra_units is None:
        max_extra_units=max(4.0,gap+2.0)
    step=max(0.5,float(step))
    out=[]
    x=0.0
    while x <= float(max_extra_units)+1e-9:
        out.append(round(x,2))
        x+=step
    return out

def evaluate_hybrid_option(base_review_units_by_case: Dict[str,float],
                           available_review_units: float,
                           evidence_plan: Dict[str,Any],
                           extra_units: float) -> Dict[str,Any]:
    effective=float(evidence_plan["capacity_multiplier"]["effective_portfolio_review_units"])
    available=float(available_review_units)+float(extra_units)
    residual=max(0.0,effective-available)
    over=max(0.0,available-effective)
    coverage=round(100*min(available,effective)/max(1.0,effective),2)

    # Efficiency: reward closure and coverage, penalize extra units and overprovisioning.
    score=round(
        coverage
        - 6.0*float(extra_units)
        - 3.0*over
        - 10.0*residual,
        3
    )
    return {
        "extra_review_units_proxy":round(float(extra_units),2),
        "total_available_review_units_proxy":round(available,2),
        "effective_review_demand_units":round(effective,2),
        "residual_capacity_gap_units":round(residual,2),
        "overprovisioning_units_proxy":round(over,2),
        "coverage_pct":coverage,
        "gap_closed":residual<=0,
        "hybrid_efficiency_score":score,
        "staffing_equivalent_claimed":False,
        "financial_cost":False,
        "budget_commitment":False,
    }

def pareto_frontier(rows: List[Dict[str,Any]]) -> List[Dict[str,Any]]:
    # Max coverage, min extra units, min overprovisioning, min residual gap.
    front=[]
    for a in rows:
        dominated=False
        for b in rows:
            if a is b:
                continue
            weak=(
                b["coverage_pct"]>=a["coverage_pct"]
                and b["extra_review_units_proxy"]<=a["extra_review_units_proxy"]
                and b["overprovisioning_units_proxy"]<=a["overprovisioning_units_proxy"]
                and b["residual_capacity_gap_units"]<=a["residual_capacity_gap_units"]
            )
            strict=(
                b["coverage_pct"]>a["coverage_pct"]
                or b["extra_review_units_proxy"]<a["extra_review_units_proxy"]
                or b["overprovisioning_units_proxy"]<a["overprovisioning_units_proxy"]
                or b["residual_capacity_gap_units"]<a["residual_capacity_gap_units"]
            )
            if weak and strict:
                dominated=True
                break
        if not dominated:
            front.append(a)
    return sorted(front,key=lambda x:(
        not x["gap_closed"],
        x["extra_review_units_proxy"],
        x["overprovisioning_units_proxy"],
        -x["coverage_pct"],
    ))

def hybrid_capacity_strategy(cases: List[Dict[str,Any]],
                             base_review_units_by_case: Dict[str,float],
                             available_review_units: float,
                             step: float=1.0) -> Dict[str,Any]:
    evidence_plan=shared_evidence_capacity_plan(
        cases,base_review_units_by_case,available_review_units
    )
    residual=float(
        evidence_plan["residual_capacity_gap"]["residual_capacity_gap_units"]
    )
    candidates=[
        evaluate_hybrid_option(
            base_review_units_by_case,available_review_units,evidence_plan,x
        )
        for x in augmentation_candidates(residual,step=step)
    ]
    frontier=pareto_frontier(candidates)

    closed=[r for r in frontier if r["gap_closed"]]
    if closed:
        recommended=sorted(
            closed,key=lambda x:(
                x["extra_review_units_proxy"],
                x["overprovisioning_units_proxy"],
                -x["hybrid_efficiency_score"],
            )
        )[0]
        posture="MINIMUM_HYBRID_CLOSURE_CANDIDATE"
    else:
        recommended=max(
            frontier,key=lambda x:(x["coverage_pct"],-x["extra_review_units_proxy"])
        ) if frontier else None
        posture="HYBRID_GAP_REMAINS_OPEN"

    return {
        "evidence_reuse_plan":evidence_plan,
        "candidate_count":len(candidates),
        "candidates":candidates,
        "pareto_frontier":frontier,
        "recommended_candidate":recommended,
        "posture":posture,
        "optimization_order":[
            "ELIGIBLE_EVIDENCE_REUSE",
            "RESIDUAL_GAP_MEASUREMENT",
            "MINIMUM_AUGMENTATION",
            "OVERPROVISIONING_CHECK",
            "HUMAN_RESOURCE_DECISION"
        ],
        "assurance_threshold_relaxed":False,
        "double_counting_prohibited":True,
        "automatic_staffing_change":False,
        "automatic_rebalance":False,
        "budget_commitment":False,
        "procurement_execution":False,
        "automatic_scheduling":False,
        "human_authority_required":True,
        "semantics":"reuse-first then minimum abstract augmentation; no staffing or budget execution",
    }

def explain_hybrid_gain(strategy: Dict[str,Any]) -> Dict[str,Any]:
    ep=strategy["evidence_reuse_plan"]
    rec=strategy["recommended_candidate"]
    base=ep["capacity_multiplier"]["base_portfolio_review_units"]
    effective=ep["capacity_multiplier"]["effective_portfolio_review_units"]
    avoided=ep["capacity_multiplier"]["review_units_avoided_proxy"]
    return {
        "base_review_demand_units":base,
        "effective_demand_after_reuse":effective,
        "reuse_units_avoided_proxy":avoided,
        "minimum_extra_units_proxy":rec["extra_review_units_proxy"] if rec else None,
        "final_coverage_pct":rec["coverage_pct"] if rec else None,
        "final_residual_gap_units":rec["residual_capacity_gap_units"] if rec else None,
        "overprovisioning_units_proxy":rec["overprovisioning_units_proxy"] if rec else None,
        "physical_capacity_created":False,
        "headcount_equivalent":False,
        "financial_savings_claimed":False,
    }
