
from __future__ import annotations
from itertools import product
from typing import Dict, Any, List
import math
import statistics
from hybrid_capacity_strategy import hybrid_capacity_strategy

DEFAULT_DEMAND_MULTIPLIERS=(1.00,1.10,1.25,1.50)
DEFAULT_REUSE_RETENTION=(1.00,0.50,0.00)
DEFAULT_BURDEN_ERROR=(1.00,1.15,1.30)
DEFAULT_SIMULTANEOUS_REOPENS=(0,1,2)

def bounded_stress_scenarios(max_scenarios: int=48,
                             demand_multipliers=DEFAULT_DEMAND_MULTIPLIERS,
                             reuse_retention=DEFAULT_REUSE_RETENTION,
                             burden_error=DEFAULT_BURDEN_ERROR,
                             simultaneous_reopens=DEFAULT_SIMULTANEOUS_REOPENS) -> List[Dict[str,Any]]:
    """
    Deterministically spread a bounded sample across the full Cartesian scenario
    space. This avoids lexicographic truncation bias while remaining reproducible.
    """
    full=[
        {
            "demand_multiplier":float(d),
            "reuse_retention_fraction":float(r),
            "burden_estimation_multiplier":float(b),
            "simultaneous_reopened_cases":int(s),
        }
        for d,r,b,s in product(
            demand_multipliers,reuse_retention,burden_error,simultaneous_reopens
        )
    ]
    if not full:
        return []
    limit=max(1,min(int(max_scenarios),len(full)))
    if limit>=len(full):
        return full
    if limit==1:
        return [full[0]]

    # Evenly spaced deterministic indices across [0, len(full)-1].
    idxs=[]
    for i in range(limit):
        idx=round(i*(len(full)-1)/(limit-1))
        if idx not in idxs:
            idxs.append(idx)

    # Rare rounding collision fallback: fill from remaining points in order.
    if len(idxs)<limit:
        for idx in range(len(full)):
            if idx not in idxs:
                idxs.append(idx)
            if len(idxs)>=limit:
                break

    return [full[i] for i in sorted(idxs[:limit])]

def evaluate_stress_scenario(base_review_demand: float,
                             reuse_units_avoided: float,
                             available_hybrid_capacity: float,
                             scenario: Dict[str,Any],
                             reopen_burden_units_per_case: float=1.0) -> Dict[str,Any]:
    stressed_base=(
        float(base_review_demand)
        * float(scenario["demand_multiplier"])
        * float(scenario["burden_estimation_multiplier"])
    )
    retained_reuse=max(
        0.0,
        float(reuse_units_avoided) * float(scenario["reuse_retention_fraction"])
    )
    reopen_burden=max(
        0.0,
        int(scenario["simultaneous_reopened_cases"]) * float(reopen_burden_units_per_case)
    )
    stressed_effective=max(0.0,stressed_base-retained_reuse+reopen_burden)
    capacity=max(0.0,float(available_hybrid_capacity))
    gap=max(0.0,stressed_effective-capacity)
    coverage=round(100*min(capacity,stressed_effective)/max(1.0,stressed_effective),2)

    return {
        **scenario,
        "stressed_base_review_demand_units":round(stressed_base,2),
        "retained_reuse_credit_units":round(retained_reuse,2),
        "simultaneous_reopen_burden_units":round(reopen_burden,2),
        "stressed_effective_review_demand_units":round(stressed_effective,2),
        "available_hybrid_capacity_units":round(capacity,2),
        "residual_capacity_gap_units":round(gap,2),
        "capacity_coverage_pct":coverage,
        "gap_closed":gap<=0,
        "scenario_is_probability":False,
    }

def _nearest_rank(values: List[float], pct: float) -> float:
    if not values:
        return 0.0
    vals=sorted(values)
    pct=max(0.0,min(100.0,float(pct)))
    rank=max(1,math.ceil((pct/100.0)*len(vals)))
    return float(vals[rank-1])

def robustness_envelope(rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    gaps=[float(r["residual_capacity_gap_units"]) for r in rows]
    coverage=[float(r["capacity_coverage_pct"]) for r in rows]
    closed=sum(1 for r in rows if r["gap_closed"])
    n=max(1,len(rows))

    scenario_pass_rate=round(100*closed/n,2)
    worst=max(gaps) if gaps else 0.0
    median=round(statistics.median(gaps),2) if gaps else 0.0
    p80=round(_nearest_rank(gaps,80),2)
    p90=round(_nearest_rank(gaps,90),2)

    if scenario_pass_rate>=90 and worst<=2:
        band="ROBUST_WITHIN_BOUNDED_SCENARIOS"
    elif scenario_pass_rate>=60:
        band="CONDITIONALLY_ROBUST_WITHIN_BOUNDED_SCENARIOS"
    else:
        band="FRAGILE_WITHIN_BOUNDED_SCENARIOS"

    return {
        "scenario_count":len(rows),
        "closed_scenario_count":closed,
        "scenario_pass_coverage_pct":scenario_pass_rate,
        "scenario_pass_rate_is_probability":False,
        "median_residual_gap_units":median,
        "p80_residual_gap_units":p80,
        "p90_residual_gap_units":p90,
        "worst_residual_gap_units":round(worst,2),
        "minimum_capacity_coverage_pct":round(min(coverage),2) if coverage else 0.0,
        "robustness_band":band,
    }

def contingency_capacity_range(envelope: Dict[str,Any]) -> Dict[str,Any]:
    return {
        "extra_units_for_80pct_scenario_gap_cover":envelope["p80_residual_gap_units"],
        "extra_units_for_90pct_scenario_gap_cover":envelope["p90_residual_gap_units"],
        "extra_units_for_all_tested_scenarios":envelope["worst_residual_gap_units"],
        "probabilistic_guarantee":False,
        "headcount_equivalent":False,
        "financial_budget_estimate":False,
        "human_contingency_decision_required":True,
    }

def dominant_stress_drivers(rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    if not rows:
        return {"drivers":[],"worst_scenario":None,"causality_proven":False,"stress_attribution_only":True}
    worst=max(rows,key=lambda r:r["residual_capacity_gap_units"])
    drivers=[]
    if worst["demand_multiplier"]>1:
        drivers.append("DEMAND_SURGE")
    if worst["reuse_retention_fraction"]<1:
        drivers.append("EVIDENCE_REUSE_DEGRADATION")
    if worst["burden_estimation_multiplier"]>1:
        drivers.append("BURDEN_ESTIMATION_ERROR")
    if worst["simultaneous_reopened_cases"]>0:
        drivers.append("SIMULTANEOUS_REOPEN")
    return {
        "drivers":drivers,
        "worst_scenario":worst,
        "causality_proven":False,
        "stress_attribution_only":True,
    }

def capacity_robustness_assessment(cases: List[Dict[str,Any]],
                                   base_review_units_by_case: Dict[str,float],
                                   available_review_units: float,
                                   max_scenarios: int=48) -> Dict[str,Any]:
    hybrid=hybrid_capacity_strategy(
        cases,base_review_units_by_case,available_review_units,step=1.0
    )
    rec=hybrid["recommended_candidate"]
    evidence_plan=hybrid["evidence_reuse_plan"]
    mult=evidence_plan["capacity_multiplier"]

    base=float(mult["base_portfolio_review_units"])
    reuse_saved=float(mult["review_units_avoided_proxy"])
    available_hybrid=float(available_review_units)+float(rec["extra_review_units_proxy"])

    scenarios=bounded_stress_scenarios(max_scenarios=max_scenarios)
    rows=[
        evaluate_stress_scenario(base,reuse_saved,available_hybrid,s)
        for s in scenarios
    ]
    envelope=robustness_envelope(rows)
    contingency=contingency_capacity_range(envelope)
    drivers=dominant_stress_drivers(rows)

    if envelope["robustness_band"]=="ROBUST_WITHIN_BOUNDED_SCENARIOS":
        posture="HYBRID_PLAN_ROBUST_WITHIN_TESTED_ENVELOPE"
    elif envelope["robustness_band"]=="CONDITIONALLY_ROBUST_WITHIN_BOUNDED_SCENARIOS":
        posture="CONTINGENCY_REVIEW_RECOMMENDED"
    else:
        posture="HYBRID_PLAN_STRESS_VULNERABLE"

    return {
        "baseline_hybrid_strategy":hybrid,
        "stress_scenarios":rows,
        "robustness_envelope":envelope,
        "contingency_capacity_range":contingency,
        "dominant_stress_drivers":drivers,
        "posture":posture,
        "probabilistic_forecast":False,
        "automatic_staffing_change":False,
        "automatic_rebalance":False,
        "budget_commitment":False,
        "procurement_execution":False,
        "automatic_scheduling":False,
        "human_contingency_decision_required":True,
        "semantics":"bounded deterministic stress coverage; scenario pass rate is not probability",
    }
