(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const text = (id, value) => { const el=$(id); if(el) el.textContent=String(value ?? "—"); };
  const compact = (value) => {
    if (value === null || value === undefined) return "—";
    if (typeof value === "string") return value;
    return JSON.stringify(value);
  };
  const setChip = (id, label, kind="neutral") => {
    const el=$(id); if(!el) return; el.textContent=label; el.className=`chip ${kind}`;
  };
  const escapeLine = (s) => String(s ?? "").replace(/[\r\n]+/g," ").slice(0,1200);

  function exposeReadOnlyShell(){
    const auth=$("authShell"), app=$("appShell");
    if(auth) auth.hidden=true;
    if(app){ app.hidden=false; app.style.display="grid"; }
    document.body.classList.remove("auth-pending");
    document.body.classList.add("analytical-api-mode");
    text("operatorName","Analytical Engine");
    text("operatorRole","Human-governed advisory mode");
    const badge=$("collectorBadge"); if(badge){ badge.className="collector-pill"; badge.textContent="● Core API connecting"; }
    const strength=$("authStrengthChip"); if(strength){ const sp=strength.querySelector("span"); if(sp) sp.textContent="Read-only analytical service"; }
  }

  function wireNavigation(){
    document.querySelectorAll("[data-jump]").forEach(btn=>btn.addEventListener("click",()=>{
      const target=$(btn.getAttribute("data-jump"));
      if(target) target.scrollIntoView({behavior:"smooth",block:"start"});
      if(btn.classList.contains("side-link")){
        document.querySelectorAll(".side-link").forEach(x=>x.classList.remove("active"));
        btn.classList.add("active");
      }
    }));
    const form=$("searchForm"), input=$("globalSearch");
    if(form&&input) form.addEventListener("submit",e=>{
      e.preventDefault(); const q=input.value.trim().toLowerCase(); if(!q) return;
      const target=[...document.querySelectorAll("main section, main article")].find(x=>x.textContent.toLowerCase().includes(q));
      if(target) target.scrollIntoView({behavior:"smooth",block:"start"});
    });
    document.querySelectorAll("form").forEach(f=>{if(f.id!=="searchForm") f.addEventListener("submit",e=>e.preventDefault())});
    ["loginButton","activationButton","logoutButton"].forEach(id=>{const el=$(id);if(el)el.addEventListener("click",e=>e.preventDefault())});
  }

  function renderBootstrap(data){
    const v88=data.v088||{}, v89=data.v089||{}, v90=data.v090||{};
    text("mdr-target",`${v88.target_days ?? "—"} days`);
    text("mdr-burden",v88.selected_burden ?? "—");
    text("mdr-degrade",v88.first_degradation===null?"Beyond sampled horizon":v88.first_degradation ?? "—");
    text("mdr-selected",v88.selected_portfolio || "No selected portfolio");
    text("mdr-frontier",`${v88.pareto_count ?? 0} non-dominated bounded portfolio option(s).`);
    text("mdr-comparison","Current release evidence loaded from the sealed V0.88 portfolio record.");

    text("rrcs-scenarios",v89.scenario_count ?? "—");
    text("rrcs-selected",v89.selected_portfolio || "—");
    text("rrcs-rank",v89.worst_rank ?? "—");
    text("rrcs-ranking",escapeLine(v89.posture || "Release evidence loaded."));
    text("rrcs-regret","Regret is measured in decision-support-score points, not money or probability.");
    text("rrcs-comparison",`Efficiency: ${v89.efficiency_portfolio || "—"} · Robust: ${v89.selected_portfolio || "—"}`);

    renderMpr(v90);
    setChip("coreApiStatus",`API ${data.version || "linked"}`,"good");
    const badge=$("collectorBadge"); if(badge){badge.className="collector-pill good";badge.textContent=`● Core API ${data.version || "ready"}`;}
  }

  function renderMpr(v90){
    if(!v90) return;
    const need=v90.mission_need||{}, boundary=v90.selection_boundary||{}, selected=v90.selected_portfolio_candidate||{}, opt=v90.option_comparison||{};
    text("mpr-need",need.resilience_need_index ?? "—");
    text("mpr-boundary",boundary.robustness_selection_need_threshold ?? "—");
    text("mpr-selected",selected.portfolio_id || "—");
    text("mpr-decomposition",`Need band ${need.need_band || "—"}; contributions ${compact(need.contributions || {})}`);
    text("mpr-comparison",`Premium ${opt.premium_pct_vs_efficiency_burden ?? "—"}% · robustness gain index ${opt.robustness_gain_index ?? "—"} · coverage gain ${opt.tested_coverage_gain_pct_points ?? "—"} points.`);
    text("mpr-policy",`${v90.posture || "—"} · margin ${v90.policy_margin_points ?? "—"} · ${v90.policy_boundary_stability || "—"}.`);
  }

  async function loadBootstrap(){
    setChip("coreApiStatus","Connecting…","neutral");
    try{
      const r=await fetch("/api/v1/ui/bootstrap",{cache:"no-store"});
      if(!r.ok) throw new Error(`HTTP ${r.status}`);
      const data=await r.json(); renderBootstrap(data); return data;
    }catch(err){
      setChip("coreApiStatus","API unavailable","bad");
      const badge=$("collectorBadge"); if(badge){badge.className="collector-pill warn";badge.textContent="● Core API unavailable";}
      text("mprLiveResult",`Analytical API unavailable: ${escapeLine(err.message||err)}`);
      return null;
    }
  }

  const n=(id)=>Math.max(0,Math.min(100,Number($(id)?.value||0)));
  async function runMpr(){
    const payload={
      mission_criticality:n("ctxMission"), consequence_severity:n("ctxConsequence"),
      reversibility:n("ctxReversibility"), evidence_quality:n("ctxEvidence"),
      uncertainty:n("ctxUncertainty"), external_dependency_exposure:n("ctxDependency")
    };
    const btn=$("runMprAnalysis"); if(btn) btn.disabled=true;
    text("mprLiveResult","Running bounded analytical evaluation…");
    try{
      const r=await fetch("/api/v1/renewal/mission-proportional",{
        method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(payload),cache:"no-store"
      });
      const data=await r.json(); if(!r.ok) throw new Error(data.detail||`HTTP ${r.status}`);
      renderMpr(data.analysis);
      const a=data.analysis||{}, sel=a.selected_portfolio_candidate||{};
      text("mprLiveResult",`${a.posture || "Analysis complete"} Selected ${sel.portfolio_id || "—"}; policy margin ${a.policy_margin_points ?? "—"}. Advisory only — no production action executed.`);
    }catch(err){ text("mprLiveResult",`Analysis failed: ${escapeLine(err.message||err)}`); }
    finally{ if(btn) btn.disabled=false; }
  }

  function bootstrap(){
    exposeReadOnlyShell(); wireNavigation();
    $("runMprAnalysis")?.addEventListener("click",runMpr);
    $("refreshCoreBootstrap")?.addEventListener("click",loadBootstrap);
    $("refreshAll")?.addEventListener("click",loadBootstrap);
    loadBootstrap();
  }

  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",bootstrap);
  else bootstrap();
})();
