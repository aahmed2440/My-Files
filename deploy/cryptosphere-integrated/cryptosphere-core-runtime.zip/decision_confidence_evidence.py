
from __future__ import annotations
from datetime import datetime, timezone
from typing import Dict, Any, List
from contingency_policy_sensitivity import contingency_policy_sensitivity

ASSUMPTION_FIELDS=[
    "mission_criticality",
    "consequence_severity",
    "reversibility",
    "evidence_quality",
    "uncertainty",
    "external_dependency_exposure",
]

def _clamp(v,lo=0.0,hi=100.0):
    try:
        return max(lo,min(hi,float(v)))
    except Exception:
        return lo

def _parse_time(value):
    if not value:
        return None
    try:
        dt=datetime.fromisoformat(str(value).replace("Z","+00:00"))
        if dt.tzinfo is None:
            dt=dt.replace(tzinfo=timezone.utc)
        return dt
    except Exception:
        return None

def normalize_assumption_evidence(evidence: List[Dict[str,Any]],
                                  now: datetime) -> Dict[str,Any]:
    normalized={}
    for item in evidence:
        field=item.get("assumption_field")
        if field not in ASSUMPTION_FIELDS:
            continue

        verified_at=_parse_time(item.get("verified_at"))
        age_days=None
        if verified_at is not None:
            age_days=max(0.0,(now-verified_at).total_seconds()/86400.0)

        normalized[field]={
            "assumption_field":field,
            "source_id":item.get("source_id"),
            "source_type":item.get("source_type","DECLARED"),
            "source_quality":_clamp(item.get("source_quality",0)),
            "reviewed_by_human":bool(item.get("reviewed_by_human",False)),
            "signature_verified":bool(item.get("signature_verified",False)),
            "verified_at":verified_at.isoformat() if verified_at else None,
            "age_days":round(age_days,2) if age_days is not None else None,
            "independent_corrobation":bool(item.get("independent_corrobation",False)),
            "contradiction_count":max(0,int(item.get("contradiction_count",0))),
            "notes":item.get("notes",""),
        }
    return normalized

def assumption_influence(sensitivity: Dict[str,Any]) -> Dict[str,Any]:
    one=sensitivity["one_way_sensitivity"]["rows"]
    bounds=sensitivity["policy_switch_boundaries"]["boundaries"]
    by_field={f:{"need_delta":0.0,"reserve_delta":0.0,"coverage_delta":0.0,"tier_switches":0}
              for f in ASSUMPTION_FIELDS}

    for row in one:
        f=row["field"]
        by_field[f]["need_delta"]=max(
            by_field[f]["need_delta"],abs(float(row.get("need_index_delta") or 0))
        )
        by_field[f]["reserve_delta"]=max(
            by_field[f]["reserve_delta"],abs(float(row.get("reserve_delta") or 0))
        )
        by_field[f]["coverage_delta"]=max(
            by_field[f]["coverage_delta"],abs(float(row.get("scenario_coverage_delta") or 0))
        )
        if row.get("tier_changed"):
            by_field[f]["tier_switches"]+=1

    boundary_map={r["field"]:r for r in bounds}
    rows=[]
    for f in ASSUMPTION_FIELDS:
        b=boundary_map.get(f,{})
        dist=b.get("nearest_switch_distance")
        proximity_score=0.0 if dist is None else max(0.0,100.0-_clamp(dist,0,100))
        raw=(
            4.0*by_field[f]["need_delta"]
            + 6.0*by_field[f]["reserve_delta"]
            + 1.5*by_field[f]["coverage_delta"]
            + 20.0*by_field[f]["tier_switches"]
            + 0.35*proximity_score
        )
        influence=round(min(100.0,raw),2)
        rows.append({
            "assumption_field":f,
            "influence_score":influence,
            "max_need_index_delta":round(by_field[f]["need_delta"],2),
            "max_reserve_delta":round(by_field[f]["reserve_delta"],2),
            "max_scenario_coverage_delta":round(by_field[f]["coverage_delta"],2),
            "one_way_tier_switches":by_field[f]["tier_switches"],
            "nearest_policy_switch_distance":dist,
            "causal_influence_claimed":False,
        })

    rows.sort(key=lambda x:(-x["influence_score"],x["assumption_field"]))
    return {
        "assumptions":rows,
        "influence_is_causal_effect":False,
        "global_sensitivity_claimed":False,
    }

def evidence_support_score(item: Dict[str,Any]|None,
                           max_fresh_age_days: float=30.0) -> Dict[str,Any]:
    if item is None:
        return {
            "support_score":0.0,
            "support_band":"UNSUPPORTED",
            "reasons":["NO_EVIDENCE_RECORD"],
        }

    score=0.55*_clamp(item.get("source_quality",0))
    reasons=[]

    if item.get("reviewed_by_human"):
        score+=15.0
    else:
        reasons.append("HUMAN_REVIEW_MISSING")

    if item.get("signature_verified"):
        score+=15.0
    else:
        reasons.append("SIGNATURE_VERIFICATION_MISSING")

    if item.get("independent_corrobation"):
        score+=10.0
    else:
        reasons.append("INDEPENDENT_CORROBORATION_MISSING")

    age=item.get("age_days")
    if age is None:
        reasons.append("VERIFICATION_TIME_MISSING")
        score-=10.0
    elif age>max_fresh_age_days:
        stale_penalty=min(25.0,(age-max_fresh_age_days)*0.5)
        score-=stale_penalty
        reasons.append("EVIDENCE_AGING")

    contradictions=max(0,int(item.get("contradiction_count",0)))
    if contradictions:
        score-=min(40.0,20.0*contradictions)
        reasons.append("OPEN_CONTRADICTION")

    score=round(_clamp(score),2)
    if score>=85:
        band="STRONG"
    elif score>=70:
        band="ADEQUATE"
    elif score>=50:
        band="WEAK"
    else:
        band="INSUFFICIENT"

    return {
        "support_score":score,
        "support_band":band,
        "reasons":reasons,
    }

def evidence_requirement_priority(influence: Dict[str,Any],
                                  normalized_evidence: Dict[str,Any]) -> Dict[str,Any]:
    rows=[]
    for row in influence["assumptions"]:
        field=row["assumption_field"]
        support=evidence_support_score(normalized_evidence.get(field))
        gap=round(100.0-support["support_score"],2)
        priority=round(
            (row["influence_score"]*gap)/100.0,
            2
        )
        rows.append({
            "assumption_field":field,
            "influence_score":row["influence_score"],
            "evidence_support_score":support["support_score"],
            "evidence_support_band":support["support_band"],
            "evidence_gap_score":gap,
            "evidence_priority_score":priority,
            "support_reasons":support["reasons"],
            "recommended_evidence_action":(
                "RECONCILE_CONTRADICTION"
                if "OPEN_CONTRADICTION" in support["reasons"]
                else "OBTAIN_SIGNED_HUMAN_REVIEWED_EVIDENCE"
                if support["support_score"]<70
                else "REFRESH_OR_CORROBORATE_EVIDENCE"
                if support["support_score"]<85
                else "MAINTAIN_CURRENT_EVIDENCE"
            ),
            "automatic_collection":False,
            "automatic_acceptance":False,
        })

    rows.sort(key=lambda x:(-x["evidence_priority_score"],-x["influence_score"],x["assumption_field"]))
    return {
        "ranked_requirements":rows,
        "automatic_collection":False,
        "automatic_acceptance":False,
        "human_evidence_review_required":True,
    }

def decision_confidence_decomposition(sensitivity: Dict[str,Any],
                                      evidence_requirements: Dict[str,Any]) -> Dict[str,Any]:
    region=sensitivity["decision_stability_region"]
    stability=float(region["bounded_stability_coverage_pct"])

    reqs=evidence_requirements["ranked_requirements"]
    if reqs:
        total_weight=sum(max(1.0,float(r["influence_score"])) for r in reqs)
        weighted_evidence=sum(
            max(1.0,float(r["influence_score"])) * float(r["evidence_support_score"])
            for r in reqs
        )/max(1.0,total_weight)
    else:
        weighted_evidence=0.0

    contradictions=sum(
        1 for r in reqs if "OPEN_CONTRADICTION" in r["support_reasons"]
    )
    contradiction_integrity=max(0.0,100.0-25.0*contradictions)

    # Non-probabilistic support score, intentionally conservative.
    score=round(
        0.45*stability
        + 0.45*weighted_evidence
        + 0.10*contradiction_integrity,
        2
    )

    if contradictions:
        qualification="QUALIFIED_BY_OPEN_CONTRADICTIONS"
    elif score>=85:
        qualification="STRONGLY_SUPPORTED_WITHIN_BOUNDED_MODEL"
    elif score>=70:
        qualification="SUPPORTED_WITH_EVIDENCE_GAPS"
    elif score>=55:
        qualification="MATERIALLY_QUALIFIED"
    else:
        qualification="INSUFFICIENT_ASSUMPTION_SUPPORT"

    return {
        "decision_support_score":score,
        "decision_support_score_is_probability":False,
        "stability_component":round(stability,2),
        "weighted_assumption_evidence_component":round(weighted_evidence,2),
        "contradiction_integrity_component":round(contradiction_integrity,2),
        "qualification":qualification,
        "certification_claimed":False,
        "real_world_correctness_proven":False,
    }

def prepare_assurance_model(cases,
                            base_review_units_by_case,
                            available_review_units,
                            mission_context,
                            max_scenarios=48) -> Dict[str,Any]:
    """
    Precompute the evidence-independent sensitivity/influence surface.

    Evidence actions change only the declared evidence state; they do not change
    the mission-context sensitivity model. Reusing this prepared surface avoids
    recomputing the expensive bounded scenario analysis for every candidate
    evidence action while preserving exactly the same scoring semantics.
    """
    sensitivity=contingency_policy_sensitivity(
        cases,base_review_units_by_case,available_review_units,
        mission_context,delta=10,step=5,max_scenarios=max_scenarios
    )
    influence=assumption_influence(sensitivity)
    return {
        "sensitivity":sensitivity,
        "influence":influence,
        "max_scenarios":int(max_scenarios),
    }

def assurance_from_prepared(prepared: Dict[str,Any],
                            assumption_evidence,
                            now: datetime) -> Dict[str,Any]:
    """Recompute evidence-dependent assurance from a prepared mission model."""
    sensitivity=prepared["sensitivity"]
    influence=prepared["influence"]
    normalized=normalize_assumption_evidence(assumption_evidence,now)
    requirements=evidence_requirement_priority(influence,normalized)
    decomposition=decision_confidence_decomposition(sensitivity,requirements)
    top=requirements["ranked_requirements"][0] if requirements["ranked_requirements"] else None

    if decomposition["qualification"]=="STRONGLY_SUPPORTED_WITHIN_BOUNDED_MODEL":
        posture="DECISION_EVIDENCE_STRONG"
    elif decomposition["qualification"]=="SUPPORTED_WITH_EVIDENCE_GAPS":
        posture="DECISION_SUPPORTED_REVIEW_TOP_GAPS"
    elif decomposition["qualification"]=="QUALIFIED_BY_OPEN_CONTRADICTIONS":
        posture="DECISION_HOLD_FOR_CONTRADICTION_REVIEW"
    else:
        posture="DECISION_REQUIRES_EVIDENCE_STRENGTHENING"

    return {
        "sensitivity":sensitivity,
        "normalized_assumption_evidence":normalized,
        "assumption_influence":influence,
        "evidence_requirements":requirements,
        "decision_confidence_decomposition":decomposition,
        "highest_priority_assumption":top["assumption_field"] if top else None,
        "highest_priority_evidence_score":top["evidence_priority_score"] if top else None,
        "posture":posture,
        "decision_support_score_is_probability":False,
        "automatic_evidence_collection":False,
        "automatic_evidence_acceptance":False,
        "automatic_policy_activation":False,
        "automatic_policy_mutation":False,
        "production_execution":False,
        "human_governance_required":True,
        "semantics":"bounded decision-support decomposition over sensitivity and declared evidence quality; not probability or certification",
    }

def assumption_evidence_assurance(cases,
                                  base_review_units_by_case,
                                  available_review_units,
                                  mission_context,
                                  assumption_evidence,
                                  now: datetime,
                                  max_scenarios=48) -> Dict[str,Any]:
    prepared=prepare_assurance_model(
        cases,base_review_units_by_case,available_review_units,
        mission_context,max_scenarios=max_scenarios
    )
    return assurance_from_prepared(prepared,assumption_evidence,now)
