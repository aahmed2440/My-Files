
from __future__ import annotations
from typing import Dict, Any, List
from robust_contingency_envelope import robust_contingency_policy

TIER_ORDER=["BASELINE","PRUDENT_60","STRONG_80","HIGH_ASSURANCE_90","ALL_TESTED_100"]

def normalize_mission_context(context: Dict[str,Any]) -> Dict[str,float]:
    def clamp(v,default=50):
        try:
            return max(0.0,min(100.0,float(v)))
        except Exception:
            return float(default)

    return {
        "mission_criticality":clamp(context.get("mission_criticality",50)),
        "consequence_severity":clamp(context.get("consequence_severity",50)),
        "reversibility":clamp(context.get("reversibility",50)),
        "evidence_quality":clamp(context.get("evidence_quality",50)),
        "uncertainty":clamp(context.get("uncertainty",50)),
        "external_dependency_exposure":clamp(context.get("external_dependency_exposure",25)),
    }

def resilience_need_index(context: Dict[str,Any]) -> Dict[str,Any]:
    c=normalize_mission_context(context)
    # Higher mission/consequence/uncertainty/dependency exposure increase need.
    # Higher reversibility/evidence quality reduce need.
    score=round(
        0.28*c["mission_criticality"]
        + 0.26*c["consequence_severity"]
        + 0.16*c["uncertainty"]
        + 0.12*c["external_dependency_exposure"]
        + 0.10*(100-c["reversibility"])
        + 0.08*(100-c["evidence_quality"]),
        2
    )
    if score>=85:
        band="EXTREME"
    elif score>=70:
        band="VERY_HIGH"
    elif score>=55:
        band="HIGH"
    elif score>=40:
        band="MODERATE"
    else:
        band="LOW"
    return {
        "normalized_context":c,
        "resilience_need_index":score,
        "need_band":band,
        "probability":False,
        "financial_metric":False,
    }

def tier_context_fit(tier_name: str, tier: Dict[str,Any], need: Dict[str,Any]) -> Dict[str,Any]:
    coverage=float(tier["scenario_coverage_pct"])
    reserve=float(tier["reserve_units_proxy"])
    need_score=float(need["resilience_need_index"])

    # Target coverage rises with mission need, but does not force automatic selection.
    desired=min(100.0,max(0.0,30.0+0.70*need_score))
    coverage_gap=max(0.0,desired-coverage)
    excess=max(0.0,coverage-desired)

    # Lower reserve burden is better; stronger coverage is better.
    # Excess reserve/coverage is penalized mildly to expose proportionality.
    proportionality=round(
        coverage
        - 1.6*reserve
        - 1.25*coverage_gap
        - 0.30*excess,
        3
    )

    return {
        "tier_name":tier_name,
        "reserve_units_proxy":reserve,
        "scenario_coverage_pct":coverage,
        "desired_coverage_pct_for_context":round(desired,2),
        "coverage_gap_pct":round(coverage_gap,2),
        "coverage_excess_pct":round(excess,2),
        "proportionality_score":proportionality,
        "scenario_coverage_is_probability":False,
    }

def value_of_resilience_frontier(policy: Dict[str,Any],
                                 mission_context: Dict[str,Any]) -> Dict[str,Any]:
    need=resilience_need_index(mission_context)
    tiers=policy["policy_tiers"]["tiers"]

    rows=[]
    for name in TIER_ORDER:
        tier=tiers.get(name)
        if tier is None:
            continue
        rows.append(tier_context_fit(name,tier,need))

    # Pareto: maximize coverage/proportionality while minimizing reserve.
    front=[]
    for a in rows:
        dominated=False
        for b in rows:
            if a is b:
                continue
            weak=(
                b["scenario_coverage_pct"]>=a["scenario_coverage_pct"]
                and b["proportionality_score"]>=a["proportionality_score"]
                and b["reserve_units_proxy"]<=a["reserve_units_proxy"]
            )
            strict=(
                b["scenario_coverage_pct"]>a["scenario_coverage_pct"]
                or b["proportionality_score"]>a["proportionality_score"]
                or b["reserve_units_proxy"]<a["reserve_units_proxy"]
            )
            if weak and strict:
                dominated=True
                break
        if not dominated:
            front.append(a)

    front=sorted(front,key=lambda x:(-x["proportionality_score"],x["reserve_units_proxy"]))
    return {
        "resilience_need":need,
        "tier_evaluations":rows,
        "pareto_frontier":front,
        "global_optimality_claimed":False,
        "probability_claimed":False,
    }

def select_contingency_tier(policy: Dict[str,Any],
                            mission_context: Dict[str,Any]) -> Dict[str,Any]:
    frontier=value_of_resilience_frontier(policy,mission_context)
    rows=frontier["tier_evaluations"]
    if not rows:
        return {
            "selected_tier":None,
            "selection_status":"NO_TIER_AVAILABLE",
            "human_approval_required":True,
        }

    desired=frontier["resilience_need"]["resilience_need_index"]
    desired_cov=min(100.0,max(0.0,30.0+0.70*desired))

    # Prefer the minimum tier that meets desired contextual coverage.
    meeting=[r for r in rows if r["scenario_coverage_pct"]>=desired_cov]
    if meeting:
        selected=min(meeting,key=lambda x:(x["reserve_units_proxy"],-x["proportionality_score"]))
        selection_status="CONTEXT_PROPORTIONATE_CANDIDATE"
    else:
        selected=max(rows,key=lambda x:(x["scenario_coverage_pct"],x["proportionality_score"]))
        selection_status="HIGHEST_AVAILABLE_COVERAGE_BELOW_CONTEXT_TARGET"

    return {
        "selected_tier":selected,
        "selection_status":selection_status,
        "resilience_need":frontier["resilience_need"],
        "value_of_resilience_frontier":frontier["pareto_frontier"],
        "mission_context":frontier["resilience_need"]["normalized_context"],
        "scenario_coverage_is_probability":False,
        "reserve_is_headcount":False,
        "financial_budget_estimate":False,
        "automatic_policy_activation":False,
        "automatic_staffing_change":False,
        "automatic_rebalance":False,
        "procurement_execution":False,
        "budget_commitment":False,
        "automatic_scheduling":False,
        "human_policy_selection_required":True,
        "global_optimality_claimed":False,
        "semantics":"context-proportionate contingency tier candidate over bounded tested scenarios",
    }

def adaptive_contingency_decision(cases: List[Dict[str,Any]],
                                  base_review_units_by_case: Dict[str,float],
                                  available_review_units: float,
                                  mission_context: Dict[str,Any],
                                  max_scenarios: int=48) -> Dict[str,Any]:
    base_policy=robust_contingency_policy(
        cases,
        base_review_units_by_case,
        available_review_units,
        target_scenario_coverage_pct=80.0,
        max_scenarios=max_scenarios,
        reserve_step=1.0
    )
    selection=select_contingency_tier(base_policy,mission_context)
    return {
        "base_contingency_policy":base_policy,
        "adaptive_selection":selection,
        "automatic_policy_activation":False,
        "production_execution":False,
        "human_executive_decision_required":True,
    }
