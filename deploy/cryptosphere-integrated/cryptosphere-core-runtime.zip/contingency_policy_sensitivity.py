
from __future__ import annotations
from copy import deepcopy
from typing import Dict, Any, List
import itertools
from adaptive_contingency_policy import adaptive_contingency_decision

FIELDS=[
    "mission_criticality",
    "consequence_severity",
    "reversibility",
    "evidence_quality",
    "uncertainty",
    "external_dependency_exposure",
]

def _clamp(v):
    return max(0.0,min(100.0,float(v)))

def baseline_selection(cases,base_review_units_by_case,available_review_units,
                       mission_context,max_scenarios=48):
    result=adaptive_contingency_decision(
        cases,base_review_units_by_case,available_review_units,
        mission_context,max_scenarios=max_scenarios
    )
    sel=result["adaptive_selection"]
    tier=sel.get("selected_tier") or {}
    return {
        "tier_name":tier.get("tier_name"),
        "reserve_units_proxy":tier.get("reserve_units_proxy"),
        "scenario_coverage_pct":tier.get("scenario_coverage_pct"),
        "resilience_need_index":sel["resilience_need"]["resilience_need_index"],
        "need_band":sel["resilience_need"]["need_band"],
        "selection_status":sel["selection_status"],
        "raw_result":result,
    }

def one_way_sensitivity(cases,base_review_units_by_case,available_review_units,
                        mission_context,delta=10,max_scenarios=48):
    base=baseline_selection(
        cases,base_review_units_by_case,available_review_units,
        mission_context,max_scenarios
    )
    rows=[]
    for field in FIELDS:
        original=float(mission_context.get(field,50))
        for direction,sign in (("DOWN",-1),("UP",1)):
            ctx=deepcopy(mission_context)
            ctx[field]=_clamp(original+sign*float(delta))
            x=baseline_selection(
                cases,base_review_units_by_case,available_review_units,
                ctx,max_scenarios
            )
            rows.append({
                "field":field,
                "direction":direction,
                "baseline_value":original,
                "perturbed_value":ctx[field],
                "baseline_tier":base["tier_name"],
                "perturbed_tier":x["tier_name"],
                "tier_changed":x["tier_name"]!=base["tier_name"],
                "baseline_need_index":base["resilience_need_index"],
                "perturbed_need_index":x["resilience_need_index"],
                "need_index_delta":round(
                    x["resilience_need_index"]-base["resilience_need_index"],2
                ),
                "reserve_delta":(
                    None if x["reserve_units_proxy"] is None or base["reserve_units_proxy"] is None
                    else round(float(x["reserve_units_proxy"])-float(base["reserve_units_proxy"]),2)
                ),
                "scenario_coverage_delta":(
                    None if x["scenario_coverage_pct"] is None or base["scenario_coverage_pct"] is None
                    else round(float(x["scenario_coverage_pct"])-float(base["scenario_coverage_pct"]),2)
                ),
            })
    return {
        "baseline":{k:v for k,v in base.items() if k!="raw_result"},
        "delta":float(delta),
        "rows":rows,
        "switch_count":sum(r["tier_changed"] for r in rows),
        "automatic_policy_activation":False,
        "human_review_required":True,
    }

def policy_switch_boundaries(cases,base_review_units_by_case,available_review_units,
                             mission_context,step=5,max_scenarios=48):
    base=baseline_selection(
        cases,base_review_units_by_case,available_review_units,
        mission_context,max_scenarios
    )
    boundaries=[]
    for field in FIELDS:
        original=float(mission_context.get(field,50))
        down_boundary=None
        up_boundary=None
        step_i=max(1,int(step))

        start_down=int(original)-step_i
        for value in range(start_down,-1,-step_i):
            ctx=deepcopy(mission_context)
            ctx[field]=_clamp(value)
            x=baseline_selection(
                cases,base_review_units_by_case,available_review_units,
                ctx,max_scenarios
            )
            if x["tier_name"]!=base["tier_name"]:
                down_boundary={
                    "switch_value":ctx[field],
                    "new_tier":x["tier_name"],
                    "distance_from_baseline":round(original-ctx[field],2),
                }
                break

        start_up=int(original)+step_i
        for value in range(start_up,101,step_i):
            ctx=deepcopy(mission_context)
            ctx[field]=_clamp(value)
            x=baseline_selection(
                cases,base_review_units_by_case,available_review_units,
                ctx,max_scenarios
            )
            if x["tier_name"]!=base["tier_name"]:
                up_boundary={
                    "switch_value":ctx[field],
                    "new_tier":x["tier_name"],
                    "distance_from_baseline":round(ctx[field]-original,2),
                }
                break

        distances=[
            x["distance_from_baseline"]
            for x in (down_boundary,up_boundary) if x
        ]
        nearest=min(distances) if distances else None
        boundaries.append({
            "field":field,
            "baseline_value":original,
            "baseline_tier":base["tier_name"],
            "downward_switch":down_boundary,
            "upward_switch":up_boundary,
            "nearest_switch_distance":nearest,
        })

    ranked=sorted(
        boundaries,
        key=lambda x:(
            999 if x["nearest_switch_distance"] is None else x["nearest_switch_distance"],
            x["field"]
        )
    )
    return {
        "baseline_tier":base["tier_name"],
        "step":float(step),
        "boundaries":boundaries,
        "sensitivity_ranking":ranked,
        "global_stability_claimed":False,
    }

def decision_stability_region(cases,base_review_units_by_case,available_review_units,
                              mission_context,deltas=(-10,0,10),
                              max_combinations=64,max_scenarios=48):
    base=baseline_selection(
        cases,base_review_units_by_case,available_review_units,
        mission_context,max_scenarios
    )
    rows=[]
    selected_fields=[
        "mission_criticality",
        "consequence_severity",
        "uncertainty",
        "reversibility"
    ]
    for field_a,field_b in itertools.combinations(selected_fields,2):
        for da in deltas:
            for db in deltas:
                ctx=deepcopy(mission_context)
                ctx[field_a]=_clamp(float(ctx.get(field_a,50))+float(da))
                ctx[field_b]=_clamp(float(ctx.get(field_b,50))+float(db))
                x=baseline_selection(
                    cases,base_review_units_by_case,available_review_units,
                    ctx,max_scenarios
                )
                rows.append({
                    "field_a":field_a,
                    "delta_a":da,
                    "field_b":field_b,
                    "delta_b":db,
                    "tier_name":x["tier_name"],
                    "matches_baseline":x["tier_name"]==base["tier_name"],
                    "resilience_need_index":x["resilience_need_index"],
                })
                if len(rows)>=max_combinations:
                    break
            if len(rows)>=max_combinations:
                break
        if len(rows)>=max_combinations:
            break

    stable=sum(r["matches_baseline"] for r in rows)
    coverage=round(100*stable/max(1,len(rows)),2)

    if coverage>=90:
        band="STABLE_WITHIN_BOUNDED_PERTURBATIONS"
    elif coverage>=70:
        band="MOSTLY_STABLE_WITHIN_BOUNDED_PERTURBATIONS"
    elif coverage>=50:
        band="CONDITIONALLY_STABLE_WITHIN_BOUNDED_PERTURBATIONS"
    else:
        band="FRAGILE_WITHIN_BOUNDED_PERTURBATIONS"

    return {
        "baseline_tier":base["tier_name"],
        "combination_count":len(rows),
        "stable_combination_count":stable,
        "bounded_stability_coverage_pct":coverage,
        "bounded_stability_coverage_is_probability":False,
        "stability_band":band,
        "rows":rows,
    }

def contingency_policy_sensitivity(cases,base_review_units_by_case,
                                   available_review_units,mission_context,
                                   delta=10,step=5,max_scenarios=48):
    one=one_way_sensitivity(
        cases,base_review_units_by_case,available_review_units,
        mission_context,delta,max_scenarios
    )
    bounds=policy_switch_boundaries(
        cases,base_review_units_by_case,available_review_units,
        mission_context,step,max_scenarios
    )
    region=decision_stability_region(
        cases,base_review_units_by_case,available_review_units,
        mission_context,max_scenarios=max_scenarios
    )

    nearest=next(
        (r for r in bounds["sensitivity_ranking"]
         if r["nearest_switch_distance"] is not None),
        None
    )

    if region["stability_band"]=="STABLE_WITHIN_BOUNDED_PERTURBATIONS":
        posture="DECISION_STABLE_WITHIN_TESTED_REGION"
    elif region["stability_band"]=="MOSTLY_STABLE_WITHIN_BOUNDED_PERTURBATIONS":
        posture="DECISION_MOSTLY_STABLE"
    elif region["stability_band"]=="CONDITIONALLY_STABLE_WITHIN_BOUNDED_PERTURBATIONS":
        posture="DECISION_REVIEW_SENSITIVITY"
    else:
        posture="DECISION_FRAGILE_REVIEW_REQUIRED"

    return {
        "one_way_sensitivity":one,
        "policy_switch_boundaries":bounds,
        "decision_stability_region":region,
        "most_sensitive_field":nearest["field"] if nearest else None,
        "nearest_policy_switch_distance":nearest["nearest_switch_distance"] if nearest else None,
        "posture":posture,
        "probability_claimed":False,
        "causal_effect_claimed":False,
        "automatic_policy_activation":False,
        "automatic_policy_mutation":False,
        "budget_commitment":False,
        "procurement_execution":False,
        "human_governance_required":True,
        "semantics":"bounded sensitivity/stability analysis around the declared policy context",
    }
