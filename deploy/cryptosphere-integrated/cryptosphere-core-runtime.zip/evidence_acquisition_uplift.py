
from __future__ import annotations
from copy import deepcopy
from typing import Dict, Any, List
from datetime import datetime, timezone
from decision_confidence_evidence import (
    assumption_evidence_assurance,
    prepare_assurance_model,
    assurance_from_prepared,
    normalize_assumption_evidence,
    assumption_influence,
    evidence_requirement_priority,
    decision_confidence_decomposition,
)

ACTION_LIBRARY=[
    {
        "action_id":"HUMAN_REVIEW",
        "description":"obtain human review for the existing evidence record",
        "review_burden_proxy":1.0,
        "patch":{"reviewed_by_human":True},
    },
    {
        "action_id":"SIGNATURE_VERIFY",
        "description":"verify the evidence signature",
        "review_burden_proxy":1.0,
        "patch":{"signature_verified":True},
    },
    {
        "action_id":"INDEPENDENT_CORROBORATE",
        "description":"obtain independent corroboration",
        "review_burden_proxy":2.0,
        "patch":{"independent_corrobation":True},
    },
    {
        "action_id":"REFRESH_EVIDENCE",
        "description":"refresh evidence verification timestamp and modestly improve source quality",
        "review_burden_proxy":1.5,
        "patch":{"refresh":True,"source_quality_floor":75},
    },
    {
        "action_id":"HIGH_QUALITY_SIGNED_REVIEW",
        "description":"obtain a high-quality signed human-reviewed evidence record",
        "review_burden_proxy":3.0,
        "patch":{
            "reviewed_by_human":True,
            "signature_verified":True,
            "source_quality_floor":90
        },
    },
    {
        "action_id":"FULL_ASSURANCE_REFRESH",
        "description":"obtain signed human review plus independent corroboration and fresh high-quality evidence",
        "review_burden_proxy":5.0,
        "patch":{
            "reviewed_by_human":True,
            "signature_verified":True,
            "independent_corrobation":True,
            "refresh":True,
            "source_quality_floor":95,
            "clear_contradictions":False,
        },
    },
]

def _iso(dt):
    return dt.astimezone(timezone.utc).isoformat()

def ensure_evidence_record(evidence: List[Dict[str,Any]], field: str) -> List[Dict[str,Any]]:
    rows=deepcopy(evidence)
    if any(x.get("assumption_field")==field for x in rows):
        return rows
    rows.append({
        "assumption_field":field,
        "source_id":f"candidate-{field}",
        "source_type":"PROPOSED_EVIDENCE",
        "source_quality":0,
        "reviewed_by_human":False,
        "signature_verified":False,
        "verified_at":None,
        "independent_corrobation":False,
        "contradiction_count":0,
    })
    return rows

def apply_candidate_action(evidence: List[Dict[str,Any]], field: str,
                           action: Dict[str,Any], now: datetime) -> List[Dict[str,Any]]:
    rows=ensure_evidence_record(evidence,field)
    patch=action["patch"]
    for item in rows:
        if item.get("assumption_field")!=field:
            continue
        for k,v in patch.items():
            if k in {"refresh","source_quality_floor","clear_contradictions"}:
                continue
            item[k]=v
        if patch.get("refresh"):
            item["verified_at"]=_iso(now)
        if patch.get("source_quality_floor") is not None:
            item["source_quality"]=max(
                float(item.get("source_quality",0)),
                float(patch["source_quality_floor"])
            )
        if patch.get("clear_contradictions"):
            # Reserved: never clear contradictions automatically.
            item["contradiction_count"]=item.get("contradiction_count",0)
        item["proposed_action_id"]=action["action_id"]
    return rows

def evaluate_action(cases,base_review_units_by_case,available_review_units,
                    mission_context,assumption_evidence,field,action,now,
                    max_scenarios=48,prepared_model=None,baseline_result=None) -> Dict[str,Any]:
    prepared_model=prepared_model or prepare_assurance_model(
        cases,base_review_units_by_case,available_review_units,
        mission_context,max_scenarios=max_scenarios
    )
    baseline=baseline_result or assurance_from_prepared(
        prepared_model,assumption_evidence,now
    )
    candidate_evidence=apply_candidate_action(
        assumption_evidence,field,action,now
    )
    candidate=assurance_from_prepared(
        prepared_model,candidate_evidence,now
    )

    before=float(
        baseline["decision_confidence_decomposition"]["decision_support_score"]
    )
    after=float(
        candidate["decision_confidence_decomposition"]["decision_support_score"]
    )
    uplift=round(after-before,2)
    burden=float(action["review_burden_proxy"])
    efficiency=round(uplift/max(0.5,burden),3)

    return {
        "assumption_field":field,
        "action_id":action["action_id"],
        "description":action["description"],
        "review_burden_proxy":burden,
        "baseline_decision_support_score":before,
        "modeled_after_decision_support_score":after,
        "modeled_uplift":uplift,
        "uplift_per_review_unit":efficiency,
        "baseline_qualification":baseline["decision_confidence_decomposition"]["qualification"],
        "modeled_after_qualification":candidate["decision_confidence_decomposition"]["qualification"],
        "automatic_evidence_collection":False,
        "automatic_contact":False,
        "automatic_acceptance":False,
        "production_execution":False,
    }

def candidate_action_matrix(cases,base_review_units_by_case,available_review_units,
                            mission_context,assumption_evidence,now,
                            max_scenarios=48) -> Dict[str,Any]:
    prepared_model=prepare_assurance_model(
        cases,base_review_units_by_case,available_review_units,
        mission_context,max_scenarios=max_scenarios
    )
    baseline=assurance_from_prepared(
        prepared_model,assumption_evidence,now
    )
    reqs=baseline["evidence_requirements"]["ranked_requirements"]

    # Focus on all assumptions, ordered by V0.82 evidence priority.
    fields=[r["assumption_field"] for r in reqs]
    rows=[]
    for field in fields:
        for action in ACTION_LIBRARY:
            rows.append(
                evaluate_action(
                    cases,base_review_units_by_case,available_review_units,
                    mission_context,assumption_evidence,field,action,now,
                    max_scenarios=max_scenarios,
                    prepared_model=prepared_model,baseline_result=baseline
                )
            )

    rows.sort(key=lambda x:(
        -x["uplift_per_review_unit"],
        -x["modeled_uplift"],
        x["review_burden_proxy"],
        x["assumption_field"],
        x["action_id"],
    ))
    return {
        "baseline_decision_support_score":
            baseline["decision_confidence_decomposition"]["decision_support_score"],
        "baseline_qualification":
            baseline["decision_confidence_decomposition"]["qualification"],
        "candidate_count":len(rows),
        "candidates":rows,
        "automatic_evidence_collection":False,
        "automatic_contact":False,
        "human_review_required":True,
    }

def pareto_frontier(matrix: Dict[str,Any]) -> List[Dict[str,Any]]:
    rows=matrix["candidates"]
    front=[]
    for a in rows:
        dominated=False
        for b in rows:
            if a is b:
                continue
            weak=(
                b["modeled_uplift"]>=a["modeled_uplift"]
                and b["review_burden_proxy"]<=a["review_burden_proxy"]
            )
            strict=(
                b["modeled_uplift"]>a["modeled_uplift"]
                or b["review_burden_proxy"]<a["review_burden_proxy"]
            )
            if weak and strict:
                dominated=True
                break
        if not dominated:
            front.append(a)
    return sorted(front,key=lambda x:(
        -x["uplift_per_review_unit"],
        x["review_burden_proxy"],
        -x["modeled_uplift"],
    ))

def bounded_action_portfolio(matrix: Dict[str,Any],
                             max_review_burden_proxy: float=5.0) -> Dict[str,Any]:
    """
    Greedy bounded evidence-action portfolio.
    Prevents multiple actions for the same assumption in one proposed plan.
    """
    remaining=max(0.0,float(max_review_burden_proxy))
    selected=[]
    selected_fields=set()
    for row in matrix["candidates"]:
        if row["assumption_field"] in selected_fields:
            continue
        burden=float(row["review_burden_proxy"])
        if burden<=remaining and row["modeled_uplift"]>0:
            selected.append(row)
            selected_fields.add(row["assumption_field"])
            remaining-=burden

    return {
        "review_burden_budget_proxy":float(max_review_burden_proxy),
        "used_review_burden_proxy":round(
            sum(float(r["review_burden_proxy"]) for r in selected),2
        ),
        "remaining_review_burden_proxy":round(remaining,2),
        "selected_actions":selected,
        "selected_count":len(selected),
        "portfolio_uplift_sum_proxy":round(
            sum(float(r["modeled_uplift"]) for r in selected),2
        ),
        "portfolio_uplift_sum_is_exact_joint_effect":False,
        "automatic_execution":False,
        "human_approval_required":True,
    }

def evidence_acquisition_uplift_plan(cases,base_review_units_by_case,
                                     available_review_units,mission_context,
                                     assumption_evidence,now,
                                     max_review_burden_proxy=5.0,
                                     max_scenarios=48) -> Dict[str,Any]:
    matrix=candidate_action_matrix(
        cases,base_review_units_by_case,available_review_units,
        mission_context,assumption_evidence,now,max_scenarios=max_scenarios
    )
    frontier=pareto_frontier(matrix)
    portfolio=bounded_action_portfolio(
        matrix,max_review_burden_proxy=max_review_burden_proxy
    )
    best=matrix["candidates"][0] if matrix["candidates"] else None

    if not best or best["modeled_uplift"]<=0:
        posture="NO_POSITIVE_UPLIFT_ACTION_IDENTIFIED"
    elif best["modeled_after_qualification"]=="STRONGLY_SUPPORTED_WITHIN_BOUNDED_MODEL":
        posture="HIGH_VALUE_EVIDENCE_UPLIFT_CANDIDATE"
    else:
        posture="TARGETED_EVIDENCE_STRENGTHENING_CANDIDATE"

    return {
        "candidate_matrix":matrix,
        "pareto_frontier":frontier,
        "bounded_action_portfolio":portfolio,
        "best_single_action":best,
        "posture":posture,
        "decision_support_score_is_probability":False,
        "financial_roi":False,
        "automatic_evidence_collection":False,
        "automatic_contact":False,
        "automatic_evidence_acceptance":False,
        "automatic_policy_activation":False,
        "automatic_policy_mutation":False,
        "production_execution":False,
        "human_governance_required":True,
        "semantics":"modeled evidence-strengthening uplift over bounded assumptions/actions; no evidence acquisition or execution",
    }
