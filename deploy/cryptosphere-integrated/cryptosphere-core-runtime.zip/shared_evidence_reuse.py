
from __future__ import annotations
from typing import Dict, Any, List, Tuple
from collections import defaultdict
from copy import deepcopy

REQUIRED_REUSE_FIELDS={
    "evidence_id","claim_scope","source_fingerprint","verified_at",
    "reviewed_by_human","signature_verified"
}

def evidence_fingerprint(item: Dict[str,Any]) -> Tuple:
    return (
        item.get("evidence_id"),
        item.get("claim_scope"),
        item.get("source_fingerprint"),
        item.get("verified_at"),
    )

def normalize_case_evidence(case: Dict[str,Any]) -> List[Dict[str,Any]]:
    out=[]
    for raw in case.get("reusable_evidence",[]):
        item=deepcopy(raw)
        missing=[k for k in REQUIRED_REUSE_FIELDS if k not in item]
        item["schema_complete"]=not missing
        item["missing_fields"]=missing
        item["case_id"]=case["case_id"]
        item["business_service_id"]=case.get("business_service_id")
        out.append(item)
    return out

def reuse_eligibility(item: Dict[str,Any]) -> Dict[str,Any]:
    reasons=[]
    if not item.get("schema_complete",False):
        reasons.append("SCHEMA_INCOMPLETE")
    if not item.get("reviewed_by_human",False):
        reasons.append("HUMAN_REVIEW_REQUIRED")
    if not item.get("signature_verified",False):
        reasons.append("SIGNATURE_VERIFICATION_REQUIRED")
    if not item.get("claim_scope"):
        reasons.append("CLAIM_SCOPE_MISSING")
    if not item.get("source_fingerprint"):
        reasons.append("SOURCE_FINGERPRINT_MISSING")
    if item.get("independence_required",False) and not item.get("independent_verification",False):
        reasons.append("INDEPENDENT_VERIFICATION_REQUIRED")
    if item.get("reuse_prohibited",False):
        reasons.append("REUSE_EXPLICITLY_PROHIBITED")

    return {
        "eligible":not reasons,
        "reasons":reasons,
        "automatic_acceptance":False,
        "human_validation_required":True,
    }

def shared_evidence_groups(cases: List[Dict[str,Any]]) -> List[Dict[str,Any]]:
    groups=defaultdict(list)
    for case in cases:
        for item in normalize_case_evidence(case):
            groups[evidence_fingerprint(item)].append(item)

    out=[]
    for fp,items in groups.items():
        if len(items)<2:
            continue
        eligibility=[reuse_eligibility(i) for i in items]
        all_eligible=all(e["eligible"] for e in eligibility)
        scopes={i.get("claim_scope") for i in items}
        source_fps={i.get("source_fingerprint") for i in items}
        # Scope and source must remain identical; otherwise no cross-case reuse.
        coherent=(len(scopes)==1 and len(source_fps)==1)
        out.append({
            "fingerprint":fp,
            "case_ids":sorted(i["case_id"] for i in items),
            "case_count":len(items),
            "claim_scope":next(iter(scopes)) if scopes else None,
            "source_fingerprint":next(iter(source_fps)) if source_fps else None,
            "reuse_eligible":all_eligible and coherent,
            "coherent_scope_and_source":coherent,
            "eligibility_failures":[
                {"case_id":items[idx]["case_id"],"reasons":e["reasons"]}
                for idx,e in enumerate(eligibility) if not e["eligible"]
            ],
            "double_counting_prohibited":True,
        })
    return sorted(out,key=lambda x:(not x["reuse_eligible"],-x["case_count"],str(x["fingerprint"])))

def case_review_reduction(cases: List[Dict[str,Any]], shared_groups: List[Dict[str,Any]],
                          base_review_units_by_case: Dict[str,float]) -> Dict[str,Any]:
    """
    Each eligible shared evidence group may reduce duplicate review effort after
    the first case by a bounded proxy amount. It never removes all case review.
    """
    reductions={cid:0.0 for cid in base_review_units_by_case}
    credits=[]
    for group in shared_groups:
        if not group["reuse_eligible"]:
            continue
        case_ids=group["case_ids"]
        # First case carries full review; each additional case may receive up to 1 unit credit.
        for cid in case_ids[1:]:
            base=float(base_review_units_by_case.get(cid,0))
            if base<=0:
                continue
            credit=min(1.0,base*0.25)
            reductions[cid]+=credit
            credits.append({
                "case_id":cid,
                "shared_evidence_fingerprint":group["fingerprint"],
                "review_credit_proxy":round(credit,2),
                "claim_scope":group["claim_scope"],
                "double_counting_prohibited":True,
            })

    effective={}
    for cid,base in base_review_units_by_case.items():
        # Never reduce below one review unit: each case still requires case-specific judgment.
        effective[cid]=round(max(1.0,float(base)-reductions.get(cid,0.0)),2)

    return {
        "base_review_units_by_case":base_review_units_by_case,
        "review_credit_proxy_by_case":{k:round(v,2) for k,v in reductions.items()},
        "effective_review_units_by_case":effective,
        "credits":credits,
        "case_specific_review_floor_units":1.0,
        "automatic_acceptance":False,
        "human_case_review_required":True,
    }

def effective_capacity_multiplier(base_review_units_by_case: Dict[str,float],
                                  effective_review_units_by_case: Dict[str,float]) -> Dict[str,Any]:
    base=sum(float(v) for v in base_review_units_by_case.values())
    effective=sum(float(v) for v in effective_review_units_by_case.values())
    saved=max(0.0,base-effective)
    multiplier=round(base/max(1.0,effective),3)
    return {
        "base_portfolio_review_units":round(base,2),
        "effective_portfolio_review_units":round(effective,2),
        "review_units_avoided_proxy":round(saved,2),
        "effective_capacity_multiplier":multiplier,
        "capacity_created_physical":False,
        "headcount_created":False,
        "financial_savings_claimed":False,
    }

def residual_capacity_gap(available_review_units: float,
                          effective_units: float) -> Dict[str,Any]:
    available=max(0.0,float(available_review_units))
    gap=max(0.0,float(effective_units)-available)
    coverage=round(100*min(available,effective_units)/max(1.0,effective_units),2)
    return {
        "available_review_units":round(available,2),
        "effective_review_demand_units":round(float(effective_units),2),
        "residual_capacity_gap_units":round(gap,2),
        "effective_capacity_coverage_pct":coverage,
        "capacity_sufficient_after_reuse":gap<=0,
    }

def shared_evidence_capacity_plan(cases: List[Dict[str,Any]],
                                  base_review_units_by_case: Dict[str,float],
                                  available_review_units: float) -> Dict[str,Any]:
    groups=shared_evidence_groups(cases)
    reduction=case_review_reduction(cases,groups,base_review_units_by_case)
    multiplier=effective_capacity_multiplier(
        base_review_units_by_case,reduction["effective_review_units_by_case"]
    )
    gap=residual_capacity_gap(
        available_review_units,multiplier["effective_portfolio_review_units"]
    )

    if gap["capacity_sufficient_after_reuse"]:
        posture="CAPACITY_GAP_CLOSED_BY_ELIGIBLE_EVIDENCE_REUSE"
    elif multiplier["review_units_avoided_proxy"]>0:
        posture="CAPACITY_GAP_REDUCED_BY_EVIDENCE_REUSE"
    else:
        posture="NO_ELIGIBLE_CAPACITY_MULTIPLICATION"

    return {
        "shared_groups":groups,
        "eligible_shared_group_count":sum(g["reuse_eligible"] for g in groups),
        "review_reduction":reduction,
        "capacity_multiplier":multiplier,
        "residual_capacity_gap":gap,
        "posture":posture,
        "double_counting_prohibited":True,
        "independence_requirements_preserved":True,
        "automatic_evidence_acceptance":False,
        "automatic_staffing_change":False,
        "budget_commitment":False,
        "human_approval_required":True,
        "semantics":"bounded duplicate-review reduction from eligible shared evidence; not elimination of case-specific review",
    }
