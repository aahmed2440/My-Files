
from __future__ import annotations
from typing import Dict, Any, List
from math import ceil
from capacity_robustness import capacity_robustness_assessment

def _coverage_with_reserve(stress_rows: List[Dict[str,Any]], reserve_units: float) -> Dict[str,Any]:
    reserve=max(0.0,float(reserve_units))
    closed=0
    residuals=[]
    for row in stress_rows:
        residual=max(0.0,float(row["residual_capacity_gap_units"])-reserve)
        residuals.append(residual)
        if residual<=0:
            closed+=1
    n=max(1,len(stress_rows))
    coverage=round(100*closed/n,2)
    worst=round(max(residuals),2) if residuals else 0.0
    mean=round(sum(residuals)/n,2) if residuals else 0.0
    return {
        "reserve_units_proxy":round(reserve,2),
        "closed_scenario_count":closed,
        "scenario_coverage_pct":coverage,
        "scenario_coverage_is_probability":False,
        "mean_residual_gap_units":mean,
        "worst_residual_gap_units":worst,
    }

def reserve_candidates(stress_rows: List[Dict[str,Any]], step: float=1.0,
                       max_reserve_units: float|None=None) -> List[float]:
    worst=max((float(r["residual_capacity_gap_units"]) for r in stress_rows),default=0.0)
    if max_reserve_units is None:
        max_reserve_units=ceil(worst)
    step=max(0.5,float(step))
    vals=[]
    x=0.0
    while x<=float(max_reserve_units)+1e-9:
        vals.append(round(x,2))
        x+=step
    if vals and vals[-1] < worst:
        vals.append(round(worst,2))
    return sorted(set(vals))

def contingency_frontier(stress_rows: List[Dict[str,Any]], step: float=1.0,
                         max_reserve_units: float|None=None) -> Dict[str,Any]:
    rows=[_coverage_with_reserve(stress_rows,x)
          for x in reserve_candidates(stress_rows,step,max_reserve_units)]
    # Pareto: maximize scenario coverage, minimize reserve, mean residual and worst residual.
    front=[]
    for a in rows:
        dominated=False
        for b in rows:
            if a is b: continue
            weak=(
                b["scenario_coverage_pct"]>=a["scenario_coverage_pct"]
                and b["reserve_units_proxy"]<=a["reserve_units_proxy"]
                and b["mean_residual_gap_units"]<=a["mean_residual_gap_units"]
                and b["worst_residual_gap_units"]<=a["worst_residual_gap_units"]
            )
            strict=(
                b["scenario_coverage_pct"]>a["scenario_coverage_pct"]
                or b["reserve_units_proxy"]<a["reserve_units_proxy"]
                or b["mean_residual_gap_units"]<a["mean_residual_gap_units"]
                or b["worst_residual_gap_units"]<a["worst_residual_gap_units"]
            )
            if weak and strict:
                dominated=True
                break
        if not dominated:
            front.append(a)
    return {
        "candidate_count":len(rows),
        "candidates":rows,
        "pareto_frontier":front,
        "scenario_coverage_is_probability":False,
    }

def _first_meeting(rows: List[Dict[str,Any]], target_pct: float) -> Dict[str,Any]|None:
    eligible=[r for r in rows if r["scenario_coverage_pct"]>=float(target_pct)]
    return min(eligible,key=lambda r:(r["reserve_units_proxy"],r["worst_residual_gap_units"])) if eligible else None

def policy_tiers(frontier: Dict[str,Any]) -> Dict[str,Any]:
    rows=frontier["candidates"]
    tiers={
        "BASELINE":_first_meeting(rows,0),
        "PRUDENT_60":_first_meeting(rows,60),
        "STRONG_80":_first_meeting(rows,80),
        "HIGH_ASSURANCE_90":_first_meeting(rows,90),
        "ALL_TESTED_100":_first_meeting(rows,100),
    }
    return {
        "tiers":tiers,
        "coverage_targets_are_probabilities":False,
        "automatic_activation":False,
        "human_selection_required":True,
    }

def robust_contingency_policy(cases: List[Dict[str,Any]],
                              base_review_units_by_case: Dict[str,float],
                              available_review_units: float,
                              target_scenario_coverage_pct: float=80.0,
                              max_scenarios: int=48,
                              reserve_step: float=1.0) -> Dict[str,Any]:
    robustness=capacity_robustness_assessment(
        cases,base_review_units_by_case,available_review_units,
        max_scenarios=max_scenarios
    )
    stress_rows=robustness["stress_scenarios"]
    frontier=contingency_frontier(stress_rows,step=reserve_step)
    tiers=policy_tiers(frontier)
    recommended=_first_meeting(frontier["candidates"],target_scenario_coverage_pct)

    if recommended is None:
        posture="TARGET_NOT_REACHED_WITHIN_BOUNDED_RESERVE_SEARCH"
    elif recommended["scenario_coverage_pct"]>=100:
        posture="ALL_TESTED_SCENARIOS_COVERED_BY_MODEL_RESERVE"
    elif recommended["scenario_coverage_pct"]>=90:
        posture="HIGH_ASSURANCE_CONTINGENCY_CANDIDATE"
    elif recommended["scenario_coverage_pct"]>=80:
        posture="STRONG_CONTINGENCY_CANDIDATE"
    else:
        posture="PRUDENT_CONTINGENCY_CANDIDATE"

    baseline_hybrid=robustness["baseline_hybrid_strategy"]["recommended_candidate"]
    return {
        "baseline_hybrid_extra_units_proxy":baseline_hybrid["extra_review_units_proxy"],
        "stress_robustness":robustness,
        "contingency_frontier":frontier,
        "policy_tiers":tiers,
        "target_scenario_coverage_pct":float(target_scenario_coverage_pct),
        "recommended_contingency":recommended,
        "posture":posture,
        "scenario_coverage_is_probability":False,
        "reserve_is_headcount":False,
        "financial_budget_estimate":False,
        "automatic_staffing_change":False,
        "automatic_rebalance":False,
        "procurement_execution":False,
        "budget_commitment":False,
        "automatic_scheduling":False,
        "human_policy_selection_required":True,
        "semantics":"bounded contingency reserve policy over declared stress scenarios; not probability, staffing, or budget authority",
    }

def explain_policy(policy: Dict[str,Any]) -> Dict[str,Any]:
    rec=policy.get("recommended_contingency")
    env=policy["stress_robustness"]["robustness_envelope"]
    return {
        "baseline_hybrid_extra_units_proxy":policy["baseline_hybrid_extra_units_proxy"],
        "baseline_scenario_coverage_pct":env["scenario_pass_coverage_pct"],
        "recommended_reserve_units_proxy":rec["reserve_units_proxy"] if rec else None,
        "recommended_scenario_coverage_pct":rec["scenario_coverage_pct"] if rec else None,
        "remaining_worst_gap_units":rec["worst_residual_gap_units"] if rec else None,
        "all_tested_reserve_units_proxy":policy["policy_tiers"]["tiers"]["ALL_TESTED_100"]["reserve_units_proxy"]
            if policy["policy_tiers"]["tiers"]["ALL_TESTED_100"] else None,
        "probability_claimed":False,
        "human_decision_required":True,
    }
