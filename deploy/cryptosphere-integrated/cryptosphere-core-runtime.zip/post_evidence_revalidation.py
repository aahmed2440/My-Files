
from __future__ import annotations
from copy import deepcopy
from typing import Dict, Any, List
from datetime import datetime, timedelta, timezone

from evidence_sequence_policy import evidence_sequence_policy
from evidence_acquisition_uplift import apply_candidate_action, ACTION_LIBRARY
from decision_confidence_evidence import assumption_evidence_assurance

DEFAULT_HORIZON_DAYS=(0,7,14,30,45,60,90,120,180)

def _action_lookup():
    return {a["action_id"]:a for a in ACTION_LIBRARY}

def _parse_time(value):
    if not value:
        return None
    try:
        dt=datetime.fromisoformat(str(value).replace("Z","+00:00"))
        if dt.tzinfo is None:
            dt=dt.replace(tzinfo=timezone.utc)
        return dt
    except Exception:
        return None

def apply_minimum_sufficient_sequence(cases,base_review_units_by_case,
                                      available_review_units,mission_context,
                                      assumption_evidence,start_time,
                                      max_scenarios=48):
    policy=evidence_sequence_policy(
        cases,base_review_units_by_case,available_review_units,
        mission_context,assumption_evidence,start_time,
        max_steps=5,
        min_marginal_uplift=0.50,
        max_total_review_burden_proxy=6.0,
        max_scenarios=max_scenarios
    )
    seq=policy["sequence_policy"]["sequence"]
    evidence=deepcopy(assumption_evidence)
    actions=_action_lookup()
    for row in seq:
        action=actions[row["action_id"]]
        evidence=apply_candidate_action(
            evidence,row["assumption_field"],action,start_time
        )
    return {
        "sequence_policy":policy,
        "strengthened_evidence":evidence,
        "sequence_applied_in_model":True,
        "production_execution":False,
    }

def age_evidence_state(evidence: List[Dict[str,Any]], evaluation_time: datetime) -> List[Dict[str,Any]]:
    # Evidence timestamps are not modified. Re-evaluation at a later time naturally
    # increases age_days inside V0.82 normalization.
    return deepcopy(evidence)

def bounded_assumption_drift(mission_context: Dict[str,Any], day: int) -> Dict[str,Any]:
    ctx=deepcopy(mission_context)
    # Conservative deterministic drift model for advisory testing only:
    # uncertainty and dependency exposure rise gradually; reversibility falls slightly.
    uncertainty_bump=min(15.0, day/15.0)
    dependency_bump=min(10.0, day/20.0)
    reversibility_drop=min(10.0, day/30.0)
    ctx["uncertainty"]=min(100.0,float(ctx.get("uncertainty",50))+uncertainty_bump)
    ctx["external_dependency_exposure"]=min(
        100.0,float(ctx.get("external_dependency_exposure",25))+dependency_bump
    )
    ctx["reversibility"]=max(0.0,float(ctx.get("reversibility",50))-reversibility_drop)
    return ctx

def inject_contradiction(evidence: List[Dict[str,Any]], field: str|None) -> List[Dict[str,Any]]:
    rows=deepcopy(evidence)
    if not field:
        return rows
    for item in rows:
        if item.get("assumption_field")==field:
            item["contradiction_count"]=max(1,int(item.get("contradiction_count",0)))
            item["contradiction_injected_for_model"]=True
            break
    return rows

def evaluate_support(cases,base_review_units_by_case,available_review_units,
                     mission_context,evidence,evaluation_time,max_scenarios=48):
    return assumption_evidence_assurance(
        cases,base_review_units_by_case,available_review_units,
        mission_context,evidence,evaluation_time,max_scenarios=max_scenarios
    )

def support_durability_horizon(cases,base_review_units_by_case,
                               available_review_units,mission_context,
                               strengthened_evidence,start_time,
                               horizon_days=DEFAULT_HORIZON_DAYS,
                               max_scenarios=48) -> Dict[str,Any]:
    rows=[]
    for day in horizon_days:
        t=start_time+timedelta(days=int(day))
        ctx=bounded_assumption_drift(mission_context,int(day))
        evidence=age_evidence_state(strengthened_evidence,t)
        result=evaluate_support(
            cases,base_review_units_by_case,available_review_units,
            ctx,evidence,t,max_scenarios=max_scenarios
        )
        decomp=result["decision_confidence_decomposition"]
        rows.append({
            "day":int(day),
            "evaluation_time":t.isoformat(),
            "decision_support_score":decomp["decision_support_score"],
            "qualification":decomp["qualification"],
            "top_evidence_gap":result["highest_priority_assumption"],
            "evidence_priority_score":result["highest_priority_evidence_score"],
            "bounded_assumption_drift_applied":True,
            "probability_claimed":False,
        })

    strong=[
        r for r in rows
        if r["qualification"]=="STRONGLY_SUPPORTED_WITHIN_BOUNDED_MODEL"
    ]
    first_degrade=next(
        (r for r in rows
         if r["qualification"]!="STRONGLY_SUPPORTED_WITHIN_BOUNDED_MODEL"),
        None
    )
    durable_through=max((r["day"] for r in strong),default=0)

    return {
        "rows":rows,
        "durable_through_day":durable_through,
        "first_support_degradation_day":
            first_degrade["day"] if first_degrade else None,
        "first_support_degradation_qualification":
            first_degrade["qualification"] if first_degrade else None,
        "forecast_is_probability":False,
        "automatic_revalidation":False,
    }

def contradiction_stress_cases(cases,base_review_units_by_case,
                               available_review_units,mission_context,
                               strengthened_evidence,start_time,
                               candidate_fields=None,
                               max_scenarios=48) -> Dict[str,Any]:
    fields=list(candidate_fields or [
        "consequence_severity",
        "uncertainty",
        "external_dependency_exposure"
    ])
    rows=[]
    for field in fields:
        evidence=inject_contradiction(strengthened_evidence,field)
        result=evaluate_support(
            cases,base_review_units_by_case,available_review_units,
            mission_context,evidence,start_time,max_scenarios=max_scenarios
        )
        decomp=result["decision_confidence_decomposition"]
        rows.append({
            "contradicted_assumption":field,
            "decision_support_score":decomp["decision_support_score"],
            "qualification":decomp["qualification"],
            "posture":result["posture"],
            "contradiction_is_real_world_fact":False,
            "automatic_resolution":False,
        })

    reopened=sum(
        1 for r in rows
        if r["qualification"]!="STRONGLY_SUPPORTED_WITHIN_BOUNDED_MODEL"
    )
    return {
        "cases":rows,
        "stress_case_count":len(rows),
        "support_reopened_count":reopened,
        "automatic_resolution":False,
        "human_reconciliation_required":reopened>0,
    }

def revalidation_trigger(durability: Dict[str,Any],
                         contradiction_stress: Dict[str,Any]) -> Dict[str,Any]:
    triggers=[]
    day=durability.get("first_support_degradation_day")
    if day is not None:
        triggers.append("TEMPORAL_SUPPORT_DEGRADATION")
    if contradiction_stress.get("support_reopened_count",0)>0:
        triggers.append("CONTRADICTION_REOPENS_DECISION_SUPPORT")

    if day is None:
        recommended_day=None
        window=None
    else:
        recommended_day=max(0,int(day)-1)
        window={
            "start_day":max(0,recommended_day-1),
            "preferred_day":recommended_day,
            "end_day":int(day),
        }

    return {
        "trigger_types":triggers,
        "recommended_revalidation_day":recommended_day,
        "advisory_review_window":window,
        "schedule_created":False,
        "automatic_revalidation":False,
        "automatic_policy_change":False,
        "human_revalidation_decision_required":bool(triggers),
    }

def post_evidence_revalidation_assurance(cases,base_review_units_by_case,
                                         available_review_units,mission_context,
                                         assumption_evidence,start_time,
                                         max_scenarios=48) -> Dict[str,Any]:
    strengthened=apply_minimum_sufficient_sequence(
        cases,base_review_units_by_case,available_review_units,
        mission_context,assumption_evidence,start_time,
        max_scenarios=max_scenarios
    )
    evidence=strengthened["strengthened_evidence"]
    durability=support_durability_horizon(
        cases,base_review_units_by_case,available_review_units,
        mission_context,evidence,start_time,max_scenarios=max_scenarios
    )
    contradiction=contradiction_stress_cases(
        cases,base_review_units_by_case,available_review_units,
        mission_context,evidence,start_time,max_scenarios=max_scenarios
    )
    trigger=revalidation_trigger(durability,contradiction)

    if trigger["trigger_types"]:
        posture="REVALIDATION_GOVERNANCE_REQUIRED_WITHIN_MODELED_WINDOW"
    else:
        posture="SUPPORT_REMAINS_STRONG_WITHIN_MODELED_HORIZON"

    return {
        "minimum_sufficient_sequence":strengthened["sequence_policy"],
        "strengthened_evidence":evidence,
        "support_durability":durability,
        "contradiction_stress":contradiction,
        "revalidation_trigger":trigger,
        "posture":posture,
        "forecast_is_probability":False,
        "causal_degradation_claimed":False,
        "schedule_created":False,
        "automatic_revalidation":False,
        "automatic_evidence_collection":False,
        "automatic_policy_activation":False,
        "automatic_policy_mutation":False,
        "production_execution":False,
        "human_governance_required":True,
        "semantics":"post-evidence support durability and modeled revalidation triggers; advisory only",
    }
