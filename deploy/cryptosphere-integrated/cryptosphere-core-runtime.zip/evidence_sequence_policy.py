
from __future__ import annotations
from copy import deepcopy
from typing import Dict, Any, List
from datetime import datetime

from evidence_acquisition_uplift import (
    ACTION_LIBRARY,
    apply_candidate_action,
    candidate_action_matrix,
)
from decision_confidence_evidence import assumption_evidence_assurance, prepare_assurance_model, assurance_from_prepared

TARGET_QUALIFICATIONS={
    "STRONGLY_SUPPORTED_WITHIN_BOUNDED_MODEL",
}

def _action_lookup():
    return {a["action_id"]:a for a in ACTION_LIBRARY}

def recompute_assurance(cases,base_review_units_by_case,available_review_units,
                        mission_context,evidence,now,max_scenarios=48,prepared_model=None):
    if prepared_model is not None:
        return assurance_from_prepared(prepared_model,evidence,now)
    return assumption_evidence_assurance(
        cases,base_review_units_by_case,available_review_units,
        mission_context,evidence,now,max_scenarios=max_scenarios
    )

def next_best_action(cases,base_review_units_by_case,available_review_units,
                     mission_context,evidence,now,max_scenarios=48,
                     excluded_pairs=None,prepared_model=None,baseline_result=None):
    excluded_pairs=set(excluded_pairs or [])
    # candidate_action_matrix internally prepares once. When a prepared model is
    # supplied by a sequence, build equivalent candidates without repeating the
    # expensive sensitivity surface.
    if prepared_model is None:
        matrix=candidate_action_matrix(
            cases,base_review_units_by_case,available_review_units,
            mission_context,evidence,now,max_scenarios=max_scenarios
        )
    else:
        from evidence_acquisition_uplift import evaluate_action
        baseline_result=baseline_result or assurance_from_prepared(prepared_model,evidence,now)
        fields=[r["assumption_field"] for r in baseline_result["evidence_requirements"]["ranked_requirements"]]
        rows=[]
        for field in fields:
            for action in ACTION_LIBRARY:
                rows.append(evaluate_action(
                    cases,base_review_units_by_case,available_review_units,
                    mission_context,evidence,field,action,now,
                    max_scenarios=max_scenarios,prepared_model=prepared_model,
                    baseline_result=baseline_result
                ))
        rows.sort(key=lambda x:(-x["uplift_per_review_unit"],-x["modeled_uplift"],x["review_burden_proxy"],x["assumption_field"],x["action_id"]))
        matrix={"candidates":rows}
    for row in matrix["candidates"]:
        key=(row["assumption_field"],row["action_id"])
        if key in excluded_pairs:
            continue
        if row["modeled_uplift"]<=0:
            continue
        return row
    return None

def sequence_evidence_actions(cases,base_review_units_by_case,available_review_units,
                              mission_context,assumption_evidence,now,
                              max_steps=5,
                              min_marginal_uplift=0.50,
                              max_total_review_burden_proxy=6.0,
                              target_qualifications=None,
                              max_scenarios=48) -> Dict[str,Any]:
    target_qualifications=set(target_qualifications or TARGET_QUALIFICATIONS)
    evidence=deepcopy(assumption_evidence)
    history=[]
    used_pairs=set()
    total_burden=0.0

    prepared_model=prepare_assurance_model(
        cases,base_review_units_by_case,available_review_units,
        mission_context,max_scenarios=max_scenarios
    )
    baseline=recompute_assurance(
        cases,base_review_units_by_case,available_review_units,
        mission_context,evidence,now,max_scenarios=max_scenarios,
        prepared_model=prepared_model
    )
    current_score=float(
        baseline["decision_confidence_decomposition"]["decision_support_score"]
    )
    current_qualification=baseline["decision_confidence_decomposition"]["qualification"]

    stop_reason=None
    action_defs=_action_lookup()

    if current_qualification in target_qualifications:
        stop_reason="TARGET_QUALIFICATION_ALREADY_MET"

    for step in range(1,int(max_steps)+1):
        if stop_reason:
            break

        candidate=next_best_action(
            cases,base_review_units_by_case,available_review_units,
            mission_context,evidence,now,max_scenarios=max_scenarios,
            excluded_pairs=used_pairs,prepared_model=prepared_model,
            baseline_result=assurance_from_prepared(prepared_model,evidence,now)
        )
        if candidate is None:
            stop_reason="NO_POSITIVE_UPLIFT_ACTION_REMAINS"
            break

        if float(candidate["modeled_uplift"]) < float(min_marginal_uplift):
            stop_reason="MARGINAL_UPLIFT_BELOW_THRESHOLD"
            break

        proposed_burden=total_burden+float(candidate["review_burden_proxy"])
        if proposed_burden > float(max_total_review_burden_proxy):
            stop_reason="REVIEW_BURDEN_LIMIT_REACHED"
            break

        key=(candidate["assumption_field"],candidate["action_id"])
        action=action_defs[candidate["action_id"]]

        evidence_after=apply_candidate_action(
            evidence,candidate["assumption_field"],action,now
        )
        assurance_after=recompute_assurance(
            cases,base_review_units_by_case,available_review_units,
            mission_context,evidence_after,now,max_scenarios=max_scenarios,
            prepared_model=prepared_model
        )

        after_score=float(
            assurance_after["decision_confidence_decomposition"]["decision_support_score"]
        )
        after_qualification=assurance_after["decision_confidence_decomposition"]["qualification"]
        exact_marginal=round(after_score-current_score,2)

        history.append({
            "step":step,
            "assumption_field":candidate["assumption_field"],
            "action_id":candidate["action_id"],
            "review_burden_proxy":candidate["review_burden_proxy"],
            "before_score":round(current_score,2),
            "after_score":round(after_score,2),
            "exact_marginal_uplift":exact_marginal,
            "modeled_candidate_uplift":candidate["modeled_uplift"],
            "qualification_before":current_qualification,
            "qualification_after":after_qualification,
            "target_qualification_met":after_qualification in target_qualifications,
            "automatic_execution":False,
        })

        evidence=evidence_after
        current_score=after_score
        current_qualification=after_qualification
        total_burden=proposed_burden
        used_pairs.add(key)

        if exact_marginal < float(min_marginal_uplift):
            stop_reason="EXACT_MARGINAL_UPLIFT_BELOW_THRESHOLD"
            break

        if current_qualification in target_qualifications:
            stop_reason="TARGET_QUALIFICATION_MET"
            break

    if stop_reason is None:
        stop_reason="MAX_SEQUENCE_STEPS_REACHED"

    return {
        "baseline_score":float(
            baseline["decision_confidence_decomposition"]["decision_support_score"]
        ),
        "baseline_qualification":
            baseline["decision_confidence_decomposition"]["qualification"],
        "final_score":round(current_score,2),
        "final_qualification":current_qualification,
        "sequence":history,
        "step_count":len(history),
        "total_review_burden_proxy":round(total_burden,2),
        "stop_reason":stop_reason,
        "min_marginal_uplift_threshold":float(min_marginal_uplift),
        "max_total_review_burden_proxy":float(max_total_review_burden_proxy),
        "target_qualifications":sorted(target_qualifications),
        "automatic_execution":False,
        "human_review_required":True,
    }

def marginal_decay_profile(sequence: Dict[str,Any]) -> Dict[str,Any]:
    rows=sequence["sequence"]
    uplifts=[float(r["exact_marginal_uplift"]) for r in rows]
    diminishing=False
    if len(uplifts)>=2:
        diminishing=any(uplifts[i] < uplifts[i-1] for i in range(1,len(uplifts)))
    return {
        "marginal_uplifts":uplifts,
        "diminishing_returns_observed":diminishing,
        "last_marginal_uplift":uplifts[-1] if uplifts else None,
        "causal_interpretation":False,
    }

def evidence_sequence_policy(cases,base_review_units_by_case,available_review_units,
                             mission_context,assumption_evidence,now,
                             max_steps=5,
                             min_marginal_uplift=0.50,
                             max_total_review_burden_proxy=6.0,
                             max_scenarios=48) -> Dict[str,Any]:
    seq=sequence_evidence_actions(
        cases,base_review_units_by_case,available_review_units,
        mission_context,assumption_evidence,now,
        max_steps=max_steps,
        min_marginal_uplift=min_marginal_uplift,
        max_total_review_burden_proxy=max_total_review_burden_proxy,
        max_scenarios=max_scenarios
    )
    decay=marginal_decay_profile(seq)

    if seq["stop_reason"]=="TARGET_QUALIFICATION_MET":
        posture="MINIMUM_SUFFICIENT_EVIDENCE_SEQUENCE_FOUND"
    elif seq["stop_reason"]=="TARGET_QUALIFICATION_ALREADY_MET":
        posture="NO_ADDITIONAL_EVIDENCE_ACTION_REQUIRED"
    elif seq["stop_reason"] in {
        "MARGINAL_UPLIFT_BELOW_THRESHOLD",
        "EXACT_MARGINAL_UPLIFT_BELOW_THRESHOLD"
    }:
        posture="STOP_ON_DIMINISHING_EVIDENCE_VALUE"
    elif seq["stop_reason"]=="REVIEW_BURDEN_LIMIT_REACHED":
        posture="HUMAN_REVIEW_BURDEN_CONSTRAINT_REACHED"
    else:
        posture="FURTHER_EVIDENCE_REVIEW_REQUIRED"

    return {
        "sequence_policy":seq,
        "marginal_decay_profile":decay,
        "posture":posture,
        "decision_support_score_is_probability":False,
        "financial_roi":False,
        "automatic_evidence_collection":False,
        "automatic_contact":False,
        "automatic_evidence_acceptance":False,
        "automatic_policy_activation":False,
        "automatic_policy_mutation":False,
        "production_execution":False,
        "human_governance_required":True,
        "semantics":"stepwise evidence-action sequence with exact recomputation and conditional stop rules",
    }
