import { externalOwnerIdentity } from "./_auth.js";
export default function handler(req,res){res.setHeader("cache-control","no-store");if(req.method!=="GET")return res.status(405).json({authenticated:false,error:"GET required"});return res.status(200).json(externalOwnerIdentity(req));}
