import crypto from "node:crypto";
const PRIVILEGED=new Set(["OWNER","PRINCIPAL_ADMIN"]);
function constantTimeEqual(a,b){
  const aa=Buffer.from(String(a||"")),bb=Buffer.from(String(b||""));
  if(!aa.length||aa.length!==bb.length) return false;
  return crypto.timingSafeEqual(aa,bb);
}
export function externalOwnerIdentity(req){
  const enabled=process.env.CRYPTOSPHERE_OWNER_AUTH_MODE==="external";
  const proxyKey=process.env.CRYPTOSPHERE_IDENTITY_PROXY_KEY||"";
  const supplied=req.headers["x-cryptosphere-proxy-key"]||"";
  const principal=req.headers["x-cryptosphere-principal"]||null;
  const role=String(req.headers["x-cryptosphere-role"]||"").toUpperCase();
  const assurance=String(req.headers["x-cryptosphere-assurance"]||"").trim();
  if(!enabled||!proxyKey||!constantTimeEqual(proxyKey,supplied)||!principal||!PRIVILEGED.has(role)||!assurance||assurance.toUpperCase()==="UNVERIFIED"){
    return {authenticated:false,principal:null,role:"UNVERIFIED",assurance:"UNVERIFIED",source:"TRUSTED_EXTERNAL_IDENTITY_REQUIRED"};
  }
  return {authenticated:true,principal:String(principal).slice(0,160),role,assurance:assurance.slice(0,80),source:"TRUSTED_EXTERNAL_IDENTITY_PROXY"};
}
export function requirePrivilegedOwner(req,res){
  const identity=externalOwnerIdentity(req);
  if(!identity.authenticated){
    res.status(401).json({status:"UNAUTHORIZED",authenticated:false,role:"UNVERIFIED",error:"Trusted OWNER or PRINCIPAL_ADMIN identity with verified assurance is required for configured enterprise assets."});
    return null;
  }
  return identity;
}
