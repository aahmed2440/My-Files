export default function handler(req,res){
  res.setHeader("cache-control","no-store");
  if(req.method!=="GET") return res.status(405).json({ok:false,error:"GET required"});
  return res.status(200).json({ok:true,service:"CryptoSphere Owner Console",version:"1.4.1",state:"SERVICE_READY",time:new Date().toISOString(),production_mutation:false});
}
