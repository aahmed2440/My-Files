import dns from "node:dns/promises";
import net from "node:net";
import https from "node:https";

const blocked = new net.BlockList();
for (const [subnet,prefix] of [
  ["0.0.0.0",8],["10.0.0.0",8],["100.64.0.0",10],["127.0.0.0",8],
  ["169.254.0.0",16],["172.16.0.0",12],["192.0.0.0",24],["192.0.2.0",24],
  ["192.168.0.0",16],["198.18.0.0",15],["198.51.100.0",24],["203.0.113.0",24],
  ["224.0.0.0",4],["240.0.0.0",4]
]) blocked.addSubnet(subnet,prefix,"ipv4");
for (const [subnet,prefix] of [
  ["::",128],["::1",128],["fc00::",7],["fe80::",10],["ff00::",8],["2001:db8::",32]
]) blocked.addSubnet(subnet,prefix,"ipv6");

function normalizedHost(host){
  const h=String(host||"").trim().toLowerCase();
  return h.startsWith("[") && h.endsWith("]") ? h.slice(1,-1) : h;
}

export function isDeniedIp(address){
  const a=normalizedHost(address);
  const family=net.isIP(a);
  if(!family) return true;
  return blocked.check(a,family===4?"ipv4":"ipv6");
}

export function parseApprovedUrl(raw){
  const u=new URL(raw);
  if(u.protocol!=="https:") throw new Error("Only HTTPS assets are supported.");
  if(u.username||u.password) throw new Error("Credentials in URLs are prohibited.");
  if(u.port && u.port!=="443") throw new Error("External owner checks are restricted to HTTPS port 443.");
  const host=normalizedHost(u.hostname);
  if(host==="localhost"||host.endsWith(".localhost")) throw new Error("Local targets are prohibited.");
  if(net.isIP(host) && isDeniedIp(host)) throw new Error("Private, local, documentation, multicast, or reserved targets are prohibited.");
  return u;
}

export async function resolvePinnedPublicAddress(hostname){
  const host=normalizedHost(hostname);
  if(net.isIP(host)){
    if(isDeniedIp(host)) throw new Error("Non-public target address is prohibited.");
    return {address:host,family:net.isIP(host)};
  }
  const answers=await dns.lookup(host,{all:true,verbatim:true});
  if(!answers.length) throw new Error("Target DNS resolution returned no addresses.");
  if(answers.some(x=>isDeniedIp(x.address))) throw new Error("Target DNS resolution includes a non-public address.");
  const picked=answers.find(x=>x.family===4)||answers[0];
  return {address:picked.address,family:picked.family};
}

export async function headWithPinnedTls(url, timeoutMs=5000){
  const u=parseApprovedUrl(url);
  const pin=await resolvePinnedPublicAddress(u.hostname);
  const hostHeader=u.port ? `${u.hostname}:${u.port}` : u.hostname;
  return await new Promise((resolve)=>{
    let finished=false;
    const finish=(value)=>{ if(finished) return; finished=true; resolve(value); };
    const req=https.request({
      protocol:"https:", hostname:u.hostname, port:443,
      method:"HEAD", path:`${u.pathname}${u.search}`,
      headers:{"user-agent":"CryptoSphere-Owner-ReadOnly/1.4.1","host":hostHeader},
      servername:normalizedHost(u.hostname), rejectUnauthorized:true,
      agent:false,
      lookup:(_hostname,_opts,cb)=>cb(null,pin.address,pin.family)
    },res=>{
      const socket=res.socket;
      const cert=socket?.getPeerCertificate?.()||{};
      const cipher=socket?.getCipher?.()||{};
      finish({
        ok:true,
        http_status:res.statusCode||null,
        tls:{
          ok:true, protocol:socket?.getProtocol?.()||null,
          cipher:cipher?.name||null,
          valid_from:cert?.valid_from||null, valid_to:cert?.valid_to||null,
          subject_cn:cert?.subject?.CN||null, issuer_cn:cert?.issuer?.CN||null,
          authorized:socket?.authorized===true
        }
      });
      res.resume();
    });
    req.setTimeout(timeoutMs,()=>req.destroy(new Error("Request timeout")));
    req.on("error",e=>finish({ok:false,error:String(e.message||e).slice(0,180),http_status:null,tls:{ok:false,error:String(e.message||e).slice(0,180)}}));
    req.end();
  });
}
