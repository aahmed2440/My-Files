import { requirePrivilegedOwner } from "./_auth.js";
import { parseApprovedUrl, headWithPinnedTls } from "./_network.js";

function loadAssets(){
  if(!process.env.CRYPTOSPHERE_ASSETS_JSON) return null;
  try{
    const parsed=JSON.parse(process.env.CRYPTOSPHERE_ASSETS_JSON);
    if(!Array.isArray(parsed)) return [];
    const seen=new Set(), out=[];
    for(const x of parsed){
      if(!x||!x.id||!x.url) continue;
      const id=String(x.id).slice(0,80);
      if(seen.has(id)) continue;
      seen.add(id); out.push({...x,id});
      if(out.length>=50) break;
    }
    return out;
  }catch{ return []; }
}
function daysToExpiry(validTo){
  if(!validTo) return null;
  const ms=Date.parse(validTo)-Date.now();
  return Number.isFinite(ms)?Math.floor(ms/86400000):null;
}
export default async function handler(req,res){
  res.setHeader("cache-control","no-store");
  if(req.method!=="POST") return res.status(405).json({status:"FAILED",error:"POST required"});
  const id=String(req.body?.asset_id||"").slice(0,80);
  const list=loadAssets();
  if(list===null){
    return res.status(200).json({
      asset_id:id||null,status:"NOT_CONFIGURED",mode:"DEMO_ONLY",
      checked_at:new Date().toISOString(),
      note:"No deployment-side allowlist is configured. No external target was contacted.",
      arbitrary_targets_allowed:false,production_mutation:false
    });
  }
  const identity=requirePrivilegedOwner(req,res);
  if(!identity) return;
  const asset=list.find(x=>x.id===id);
  if(!asset) return res.status(403).json({asset_id:id||null,status:"FAILED",mode:"CONFIGURED",error:"Asset ID is not present in the deployment-side allowlist.",arbitrary_targets_allowed:false});

  let u;
  try{ u=parseApprovedUrl(asset.url); }
  catch(e){ return res.status(400).json({status:"FAILED",error:String(e.message||e).slice(0,180)}); }

  const started=Date.now();
  let observed;
  try{ observed=await headWithPinnedTls(u,5000); }
  catch(e){ observed={ok:false,error:String(e.message||e).slice(0,180),http_status:null,tls:{ok:false,error:String(e.message||e).slice(0,180)}}; }
  const latency_ms=Date.now()-started;
  const tlsInfo=observed.tls||{ok:false,error:"TLS metadata unavailable"};
  tlsInfo.days_to_expiry=daysToExpiry(tlsInfo.valid_to);
  const http_status=observed.http_status??null;
  const httpOk=Number.isInteger(http_status)&&http_status>=200&&http_status<500;
  const certNearExpiry=Number.isFinite(tlsInfo.days_to_expiry)&&tlsInfo.days_to_expiry<30;
  const degraded=!httpOk||(tlsInfo.ok&&!tlsInfo.authorized)||certNearExpiry;
  const status=!observed.ok&&!tlsInfo.ok?"FAILED":degraded?"DEGRADED":"HEALTHY";

  return res.status(200).json({
    asset_id:id,status,mode:"CONFIGURED",http_status,latency_ms,
    http_error:observed.ok?null:(observed.error||"Check failed"),
    tls:tlsInfo,checked_at:new Date().toISOString(),authenticated_role:identity.role,
    target_disclosed_to_client:false,resolved_address_disclosed_to_client:false,
    arbitrary_targets_allowed:false,credential_collection:false,decryption:false,production_mutation:false
  });
}
