import { requirePrivilegedOwner } from "./_auth.js";
const DEMO=[
  {id:"demo-fleet-edge",name:"Demo Fleet Edge",scope:"fleet",type:"HTTPS endpoint",environment:"demo",tags:["fleet","edge"]},
  {id:"demo-enterprise-api",name:"Demo Enterprise API",scope:"enterprise",type:"HTTPS endpoint",environment:"demo",tags:["enterprise","api"]}
];
function configured(){
  if(!process.env.CRYPTOSPHERE_ASSETS_JSON) return null;
  try{
    const parsed=JSON.parse(process.env.CRYPTOSPHERE_ASSETS_JSON); if(!Array.isArray(parsed)) return [];
    const seen=new Set(),out=[]; for(const x of parsed){if(!x||!x.id||!x.url)continue;const id=String(x.id).slice(0,80);if(seen.has(id))continue;seen.add(id);out.push({...x,id});if(out.length>=50)break;} return out;
  }catch{return []}
}
function clean(a){return {id:a.id,name:String(a.name||a.id).slice(0,120),scope:a.scope==="fleet"?"fleet":"enterprise",type:String(a.type||"HTTPS endpoint").slice(0,80),environment:String(a.environment||"unknown").slice(0,50),tags:Array.isArray(a.tags)?a.tags.map(x=>String(x).slice(0,40)).slice(0,12):[]}}
export default function handler(req,res){
  res.setHeader("cache-control","no-store"); if(req.method!=="GET")return res.status(405).json({status:"FAILED",error:"GET required"});
  const list=configured(); if(list===null)return res.status(200).json({mode:"DEMO_ONLY",assets:DEMO,arbitrary_targets_allowed:false});
  const identity=requirePrivilegedOwner(req,res); if(!identity)return;
  return res.status(200).json({mode:"CONFIGURED",assets:list.map(clean),authenticated_role:identity.role,arbitrary_targets_allowed:false});
}
